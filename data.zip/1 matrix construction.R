library(tidyverse)
library(here)
 
# process raw travel cost matrices produced by PySal (see instructions at https://pysal.org/access/resources.html)
transit <- read_csv(here("data", "transit.csv")) 
car <- read_csv(here("data", "car.csv")) 
walk <- read_csv(here("data", "walking.csv")) 

cost_matrix <- left_join(car, transit, by = c("origin", "destination")) %>% 
  left_join(walk, by = c("origin", "destination"))

# using table B08006 from 2015-2019 ACS [https://data.census.gov/table]
commuting_acs <- read_csv(here("data", "B08006.csv"))
commuting_acs <- commuting_acs[2:nrow(commuting_acs), ]
commuting_acs <- commuting_acs %>% 
  rename(GEOID = GEO_ID,
         total_pop = B08006_001E,
         total_car_pop = B08006_002E,
         total_public_transit_pop = B08006_008E,
         total_walk_pop = B08006_015E) %>% 
  select(matches("GEOID|total")) %>% 
  mutate(across(matches("total"), as.numeric)) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US")) %>% 
  mutate(commute_by_car_prop = total_car_pop / (total_car_pop + total_public_transit_pop + total_walk_pop),
         commute_by_walking_prop = total_walk_pop / (total_car_pop + total_public_transit_pop + total_walk_pop),
         commute_by_public_transport_prop = 1 - commute_by_car_prop - commute_by_walking_prop) %>% 
  select(matches("GEOID|total_pop|commute|prop")) %>%
  mutate(GEOID = as.numeric(GEOID))

cost_matrix <- left_join(cost_matrix, 
                         commuting_acs %>% 
                           select(GEOID, commute_by_public_transport_prop, commute_by_walking_prop, 
                                  commute_by_car_prop, total_pop),
                         by = c("origin" = "GEOID"))

lm_with_walking <- lm(transit_minutes ~ car_minutes * commute_by_public_transport_prop +
                        walk_minutes*commute_by_walking_prop, 
         weights = total_pop,
         data = cost_matrix %>% 
           filter(!is.na(walk_minutes))) %>% 
  broom::tidy()

lm_without_walking <- lm(transit_minutes ~ car_minutes * commute_by_public_transport_prop, 
                         weights = total_pop,
                         data = cost_matrix %>% 
                           filter(is.na(walk_minutes))) %>% 
  broom::tidy()

cost_matrix <- cost_matrix %>%
  mutate(walk_data = ifelse(!is.na(walk_minutes), TRUE, FALSE)) %>% 
  mutate(transit_minutes = 
           ifelse(is.na(transit_minutes) & walk_data == FALSE, 
                  ((lm_without_walking %>% 
                      filter(term == "(Intercept)") %>% 
                      pull(estimate)) +
                     (car_minutes*(lm_without_walking %>% 
                                     filter(term == "car_minutes") %>% 
                                     pull(estimate))) + 
                     (commute_by_public_transport_prop*(lm_without_walking %>% 
                                                          filter(term == "commute_by_public_transport_prop") %>% 
                                                          pull(estimate))) + 
                     (car_minutes*commute_by_public_transport_prop*(lm_without_walking %>% 
                                                                      filter(term == "car_minutes:commute_by_public_transport_prop") %>% 
                                                                      pull(estimate)))), 
                  transit_minutes)) %>% 
  mutate(transit_minutes = 
           ifelse(is.na(transit_minutes) & walk_data == TRUE, 
                  (lm_with_walking %>% 
                     filter(term == "(Intercept)") %>% 
                     pull(estimate)) +
                    (car_minutes*(lm_with_walking %>% 
                                    filter(term == "car_minutes") %>% 
                                    pull(estimate))) + 
                    (commute_by_public_transport_prop*(lm_with_walking %>% 
                                                         filter(term == "commute_by_public_transport_prop") %>% 
                                                         pull(estimate))) + 
                    (car_minutes*commute_by_public_transport_prop*(lm_with_walking %>% 
                                                                     filter(term == "car_minutes:commute_by_public_transport_prop") %>% 
                                                                     pull(estimate))) +
                    (walk_minutes*(lm_with_walking %>% 
                                     filter(term == "walk_minutes") %>% 
                                     pull(estimate))) +
                    (walk_minutes*commute_by_walking_prop*(lm_with_walking %>% 
                                                             filter(term == "walk_minutes:commute_by_walking_prop") %>% 
                                                             pull(estimate))), 
                  transit_minutes)) %>% 
  mutate(transit_minutes = ifelse(is.na(car_minutes) | is.na(commute_by_public_transport_prop), NA, transit_minutes)) %>% 
  mutate(transit_minutes = ifelse(transit_minutes <= 0.01, car_minutes, transit_minutes))

cost_matrix <- cost_matrix %>% 
  mutate(walk_minutes = ifelse(is.na(walk_minutes), transit_minutes, walk_minutes))

cost_matrix <- cost_matrix %>% 
  select(-c(walk_data, total_pop))

# using table S0101 from 2015-2019 ACS [https://data.census.gov/table]
acs <- read_csv(here("data", "S0101.csv")) %>% 
  select(GEOID = GEO_ID,
         total_pop = S0101_C01_001E) %>% 
    mutate(GEOID = str_remove(GEOID, ".*US")) %>%
    mutate_all(as.numeric)
  
acs <- acs[2:nrow(acs), ]

cost_matrix <- cost_matrix %>% 
  left_join(acs, by = c("origin" = "GEOID")) %>% 
  mutate(total_pop_car = round(total_pop * commute_by_car_prop),
         total_pop_walk = round(total_pop * commute_by_walking_prop),
         total_pop_public_transport = round(total_pop * commute_by_public_transport_prop)) %>% 
  select(-c(commute_by_public_transport_prop, commute_by_walking_prop, commute_by_car_prop, total_pop)) 

cost_matrix <- cost_matrix %>% 
  pivot_longer(c(total_pop_car, total_pop_walk, total_pop_public_transport), names_to = "modality", values_to = "total_pop") %>% 
  mutate(modality = case_when(modality == "total_pop_car" ~ "car",
                              modality == "total_pop_walk" ~ "walk",
                              modality == "total_pop_public_transport" ~ "transit")) %>% 
  mutate(minutes = ifelse(modality == "car", car_minutes,
                          ifelse(modality == "walk", walk_minutes, transit_minutes))) %>% 
  select(-c(car_minutes, transit_minutes, walk_minutes)) %>% 
  mutate(origin = paste0(origin, "_", modality)) %>% 
  select(-modality) %>% 
  filter(!is.na(minutes) & !is.na(total_pop))

# saving files
cost_matrix %>% 
  select(origin, destination, minutes) %>%
  write_csv(here("data", "combined.csv"))

left_join(commuting_acs,
          acs %>% select(GEOID, total_pop) %>% 
            mutate(GEOID = as.numeric(GEOID))) %>% 
  mutate(total_pop_car = round(total_pop * commute_by_car_prop),
         total_pop_walk = round(total_pop * commute_by_walking_prop),
         total_pop_public_transport = round(total_pop * commute_by_public_transport_prop)) %>% 
  select(GEOID, matches("total_pop"), -total_pop) %>% 
  pivot_longer(matches("total"), values_to = "total_pop", names_to = "modality") %>% 
  mutate(modality = case_when(modality == "total_pop_car" ~ "car",
                              modality == "total_pop_walk" ~ "walk",
                              modality == "total_pop_public_transport" ~ "transit")) %>% 
  mutate(origin = paste0(GEOID, "_", modality)) %>% 
  select(origin, total_pop) %>% 
  filter(total_pop > 0) %>% 
  write_csv(here("data", "population.csv"))

left_join(commuting_acs,
          acs %>% select(GEOID, total_pop) %>% 
            mutate(GEOID = as.numeric(GEOID))) %>% 
  mutate(total_pop_car = round(total_pop * commute_by_car_prop),
         total_pop_walk = round(total_pop * commute_by_walking_prop),
         total_pop_public_transport = round(total_pop * commute_by_public_transport_prop)) %>% 
  select(GEOID, matches("total_pop"), -total_pop) %>% 
  pivot_longer(matches("total"), values_to = "total_pop", names_to = "modality") %>% 
  mutate(modality = case_when(modality == "total_pop_car" ~ "car",
                              modality == "total_pop_walk" ~ "walk",
                              modality == "total_pop_public_transport" ~ "transit")) %>% 
  mutate(origin = paste0(GEOID, "_", modality)) %>% 
  select(origin, total_pop) %>% 
  filter(total_pop > 0) %>% 
  mutate(temp = str_extract(origin, "\\d+")) %>% 
  mutate(temp = str_pad(temp, width = 11, side = "left", pad = "0")) %>% 
  mutate(two_digits = str_extract(temp, "^..")) %>% 
  filter(!two_digits %in% c("01", "15", "20", "21", "24", "27", "28", "32", "33", "35", "46", "53", "56")) %>% 
  select(origin, total_pop) %>% 
  write_csv(here("data", "population_therapists.csv"))