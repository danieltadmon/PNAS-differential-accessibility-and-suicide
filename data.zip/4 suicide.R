# packages
library(tidyverse)
library(extrafont) 
library(here) 
library(gt)
library(sf) 
library(patchwork)
library(spdep)
library(spatialreg)
library(glmnet)
library(mapboxapi)

options(scipen = 99999)

# sources
source(here("loading data - step 1.R"))
source(here("loading data - step 2.R"))
source(here("loading data - step 3.R"))
source(here("loading data - step 4.R"))
source(here("loading data - step 5.R"))

# functions
create_quantile_column_function <- function(df, variable, n){
  df <- df %>% 
    mutate(temp_variable = {{variable}}) 
  
  quintiles <- Hmisc::wtd.quantile(
    df$temp_variable, 
    weights = df$temp_weighting_variable, 
    probs = seq(1/n, 1, 1/n))
  
  df$quintile <- NA
  for(i in 1:(n)){
    df <- df %>% 
      mutate(quintile = ifelse(is.na(quintile), ifelse(temp_variable <= quintiles[i], i, NA), quintile))
  }
  
  df <- df %>% select(-temp_variable)
  
  return(df)  
}

adjust_p <- function(x, toggle_p = TRUE) {
  
  if (toggle_p){
    
    x <- ifelse(is.na(x), "...",
                ifelse(x < .001, "*p* < .001",
                       ifelse(x >= .001 & x < .01, paste0("*p* = ", round(x, 3)),
                              ifelse(x >= .01 & x < .045, paste0("*p* = ", round(x, 2)),
                                     ifelse(x >= .045 & x < .05, "*p* < .05",
                                            ifelse(x >= .05, paste0("*p* = ", round(x, 2)), NA))))))
    
  } else {
    
    x <- ifelse(is.na(x), "...",
                ifelse(x < .001, "< .001",
                       ifelse(x >= .001 & x < .01, round(x, 3),
                              ifelse(x >= .01 & x < .045, round(x, 2),
                                     ifelse(x >= .045 & x < .05, "< .05",
                                            ifelse(x >= .05, round(x, 2), NA))))))
    
  }
  
  return(x)
}

prettify <- function(x) {
  if (round(x, 0) == x) prettyNum(x, big.mark = ",")
  else format(round(x, 2), nsmall = 2)
}

fix_terms <- function(df){
  df %>% 
    mutate(term = case_when(
      term == "separated_or_divorced_in_10_pct" ~ "Separated or divorced",
      term == "pct_born_in_the_usa_in_10_pct" ~ "USA born",
      term == "insurance_rate_in_10_pct" ~ "Health insurance holders",
      term == "unemployment_rate_in_10_pct" ~ "Unemployed",
      term == "median_age" ~ "Age (median)",
      term == "county_gini_psychiatrist" ~ "Psychiatrist accessibility Gini",
      term == "psychiatrist_general_tract_access" ~ "Psychiatrist accessibility",
      term == "med_household_income_in_10K" ~ "Median household income",
      term == "acs_county_level_gini" ~ "Income inequality Gini",
      term == "rurality_1_to_10" ~ "Rurality",
      term == "insurance_rate_in_10_pct" ~ "Insurance holders",
      term == "soc_capital_community_health" ~ "Social cap.: Community health",
      term == "soc_capital_collective_efficacy" ~ "Social cap.: Collective efficacy",
      term == "soc_capital_family_unity" ~ "Social cap.: Family integration",
      term == "soc_capital_institutional_health" ~ "Social cap.: Institutional health",
      term == "gun_store_ratio" ~ "Gun store ratio",
      term == "males_in_10_pct" ~ "Gender (male)",
      term == "ADI_NATRANK" ~ "Area Deprivation Index",
      term == "pop_density_1k_ppl_per_sq_mile" ~ "Population density",
      term == "therapist_general_tract_access" ~ "Psychotherapist accessibility",
      term == "psychiatrist_availaibility" ~ "Psychiatrist PPR",
      term == "therapist_availability" ~ "Psychotherapist PPR",
      term == "county_gini_therapist" ~ "Therapist accessibility Gini",
      term == "poverty_in_10_pct" ~ "Living in poverty",
      term == "ba_degree_over_25_prop_in_10_pct" ~ "BA degree or higher",
      term == "pop_white_non_hispanic_in_10_pct" ~ "White",
      term == "pop_black_non_hispanic_in_10_pct" ~ "Black",
      term == "pop_hispanic_all_races_in_10_pct" ~ "Hispanic",
      term == "pop_asian_non_hispanic_in_10_pct" ~ "Asian",
      term == "liquor_and_drinking_ratio" ~ "Drinking establishment ratio",
      TRUE ~ term)) 
}

factorize_terms <- function(df){
  df %>%   
    mutate(term = factor(term, levels = c("Psychiatrist accessibility", "Psychiatrist accessibility Gini",
                                          "Psychiatrist PPR",
                                          "Psychotherapist accessibility",
                                          "Psychotherapist accessibility Gini",
                                          "Psychotherapist PPR",
                                          "", 
                                          "Age (median)", "Gender (male)", "White", "Black", "Asian", "Hispanic",
                                          "Median household income", "Income inequality Gini",
                                          "BA degree or higher",
                                          "Unemployed", "Living in poverty",
                                          "USA born", "Health insurance holders",
                                          "Separated or divorced",
                                          "Area Deprivation Index",
                                          "Rurality",
                                          "Population density",
                                          "Social cap.: Community health", "Social cap.: Collective efficacy",
                                          "Social cap.: Family integration", "Social cap.: Institutional health",
                                          "Gun store ratio", "Drinking establishment ratio"))) %>% 
    arrange((term)) 
}

# rate to prop.
access_df$suicide_rate <- access_df$suicide_rate / 100000
access_df$homicide_rate <- access_df$homicide_rate / 100000

# CAR ratio
CARBayes_ratio <- 1

# PPR stats
county_total_pop <- access_df %>% 
  group_by(county_code) %>% 
  summarize(total_pop = sum(total_pop, na.rm = TRUE)) %>% 
  ungroup

provider_availability_df <- access_df %>% 
  distinct(county_code, county_psychiatrist_count, county_therapist_count) %>% 
  left_join(county_total_pop) %>% 
  mutate(psychiatrist_availaibility = county_psychiatrist_count / (total_pop / 100000),
         therapist_availability = county_therapist_count / (total_pop / 100000)) %>% 
  select(county_code, psychiatrist_availaibility, therapist_availability)

access_df <- access_df %>% 
  left_join(provider_availability_df)

access_df <- access_df %>% 
  mutate(therapist_availability = 
           ifelse((!is.na(therapist_general_tract_access)) & (is.na(therapist_availability)), 0, therapist_availability))

rm(county_total_pop, provider_availability_df)

zero_psychiatrist_availability_counties <- access_df %>% 
  filter(psychiatrist_availaibility == 0)

rm(zero_psychiatrist_availability_counties)

# Cooper and Boone
cooper <- access_df[access_df$county_code == 29053, ]
boone <- access_df[access_df$county_code == 29019, ]

travel_matrix <- read_csv(here("data", "combined.csv")) %>% 
  filter(str_detect(origin, "^29053"))

psychiatrists <- read_csv(here("data", "psychiatrists.csv")) %>% 
  uncount(value) %>% 
  filter(!is.na(lon))

points <- sf::st_as_sf(psychiatrists, coords = c('lon', 'lat'), crs = 4326)
rm(psychiatrists)

# Census tract shapefile from https://www.nhgis.org
census_tract_shp <- sf::st_read(here("data", "nhgis0001_shapefile_tl2019_us_tract_2019", "US_tract_2019.shp")) %>% 
  filter(str_detect(GEOID, "^29019"))

census_tract_shp <- st_transform(census_tract_shp, crs = 4326)
census_tract_shp$psychiatrists <- lengths(st_intersects(census_tract_shp, points))

census_tract_shp <- census_tract_shp %>% 
  filter(psychiatrists > 0) %>% 
  st_drop_geometry %>% 
  select(GEOID, psychiatrists)

travel_matrix <- travel_matrix %>% 
  filter(str_detect(origin, "car$")) %>% 
  mutate(origin = str_remove(origin, "\\_car")) %>% 
  filter(destination %in% (census_tract_shp %>% pull(GEOID))) %>% 
  mutate(destination = as.character(destination))

travel_matrix <- left_join(travel_matrix, census_tract_shp, by = c("destination" = "GEOID"))
rm(census_tract_shp)
  
# using table B03002 from 2015-2019 ACS [https://data.census.gov/table]
population <- read_csv(here("data", "B03002.csv"))[-1, ] %>% 
  select(total_pop = "B03002_001E",
         GEOID = GEO_ID) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US")) 

travel_matrix <- left_join(travel_matrix, population, by = c("origin" = "GEOID"))
rm(population)

average_travel_time <- travel_matrix %>% 
  mutate(total_pop = as.numeric(total_pop)) %>% 
  mutate(weights = total_pop * psychiatrists) %>% 
  summarize(travel_time = Hmisc::wtd.mean(minutes, weights = weights),
            travel_time_sd = sqrt(Hmisc::wtd.var(minutes, weights = weights)))

travel_time_by_tract <- travel_matrix %>% 
  mutate(weights = psychiatrists) %>% 
  group_by(origin) %>%  
  summarize(travel_time = Hmisc::wtd.mean(minutes, weights = weights),
            travel_time_sd = sqrt(Hmisc::wtd.var(minutes, weights = weights)))

rm(cooper_population, travel_matrix)

# mapping Cooper and Boone counties
acs_cooper_tracts <- tidycensus::get_acs(
  geography = "tract",
  variables = "B19013_001",
  state = "MO",
  county = "Cooper",
  geometry = TRUE,
  year = 2019
)

acs_cooper_boone_tracts <- tidycensus::get_acs(
  geography = "tract",
  variables = "B19013_001",
  state = "MO",
  county = c("Cooper", "Boone"),
  geometry = TRUE,
  year = 2019
)

acs_cooper_boone_counties <- tidycensus::get_acs(
  geography = "county",
  variables = "B19013_001",
  state = "MO",
  county = c("Cooper", "Boone"),
  geometry = TRUE,
  year = 2019
)

acs_cooper_tracts <- left_join(
  acs_cooper_tracts,
  providers_psychiatrists_alone_scaled %>% 
    select(GEOID, psychiatrist_general_tract_access))

acs_cooper_boone_counties <- left_join(
  acs_cooper_boone_counties,
  access_df %>% 
    mutate(psychiatrist_availaibility_scaled = scale(psychiatrist_availaibility)) %>% 
    select(county_code, psychiatrist_general_tract_access, psychiatrist_availaibility_scaled), 
  by = c("GEOID" = "county_code"))

acs_cooper_boone_tracts <- left_join(
  acs_cooper_boone_tracts,
  providers_psychiatrists_alone_scaled %>% 
    select(GEOID, psychiatrist_general_tract_access))

cooper_boone_tiles <- get_static_tiles(
  location = acs_cooper_boone_counties,
  zoom = 10,
  style_id = "cleq9k5aw005v01p3vk71qfzr",
  username = "danieltadmon"
)

psychiatrists <- read_csv(here("data", "psychiatrists.csv")) %>% 
  uncount(value) %>% 
  filter(!is.na(lon))

points <- sf::st_as_sf(psychiatrists, coords = c('lon', 'lat'), crs = sf::st_crs(acs_cooper_boone_counties))
points <- sf::st_filter(points, acs_cooper_boone_counties)

jittered <- sf::st_jitter(points, amount = .033) 
jittered <- jittered %>% 
  sample_n(nrow(jittered) - sample(-25:25, 1))

# facets
facet_1 <- ggplot() +
  ggspatial::layer_spatial(cooper_boone_tiles) +
  ggpattern::geom_sf_pattern(
    data = acs_cooper_boone_counties[1, ],
    pattern_colour = "grey60",
    fill = "grey60",
    pattern_spacing = 0.02,
    pattern_density = 0.02,
    pattern_angle = -45,
    pattern = "stripe",
    width = .02,
    alpha = 0.5,
    color = "grey30",
    size = .5) +
  ggpattern::geom_sf_pattern(
    data = acs_cooper_boone_counties[2, ],
    pattern_colour = "grey60",
    fill = "#FFEEA1",
    pattern_spacing = 0.02,
    pattern_density = 0.02,
    pattern_angle = -45,
    pattern = "stripe",
    width = .02,
    alpha = 0.5,
    color = "grey30",
    size = .5) +
  geom_sf(
    data = acs_cooper_boone_counties[1, ],
    fill = "#206D2A",
    alpha = 0.5,
    color = "grey30",
    size = .5
  ) +
  geom_sf(
    data = acs_cooper_boone_counties,
    color = "black",
    size = 1,
    fill = NA
  ) +
  geom_sf(data = jittered, size = .75, 
          color = "#206D2A") +
  theme_void() 

facet_2 <- ggplot() +
  ggspatial::layer_spatial(cooper_boone_tiles) +
  geom_sf(data = acs_cooper_tracts, 
          fill = NA, 
          alpha = 0.5,
          color = "grey30", size = .5) +
  geom_sf(
    data = acs_cooper_boone_counties[2, ],
    color = "black",
    size = 1,
    fill = NA) +
  geom_sf(data = jittered, size = 2, 
          color = "#206D2A") +
  scale_fill_gradient(low = "#FFEEA1", high = "#206D2A", limits = c(-1, 4), breaks = c(0, 2, 4)) +
  theme_void() +
  theme(legend.position = "none") +
  coord_sf(xlim = c(sf::st_bbox(cooper_boone_tiles)['xmin'] + 31000, sf::st_bbox(cooper_boone_tiles)['xmax'] - 29250),
           ylim = c(sf::st_bbox(cooper_boone_tiles)['ymin'] + 28000, sf::st_bbox(cooper_boone_tiles)['ymax'] - 39000))

facet_3 <- ggplot() +
  ggspatial::layer_spatial(cooper_boone_tiles) +
  geom_sf(
  data = acs_cooper_boone_tracts %>% 
    rename(accessibility = psychiatrist_general_tract_access) %>% 
    mutate(accessibility = ifelse(accessibility > 4, 4, accessibility)),
  aes(fill = accessibility),
  alpha = 0.5,
  color = "grey30",
  size = .5) +
  geom_sf(
    data = acs_cooper_boone_counties,
    color = "black",
    size = 1,
    fill = NA
  ) +
  scale_fill_gradient(low = "#FFEEA1", high = "#206D2A", 
                      limits = c(NA, 4),
                      breaks = c(0, 2, 4)
                      ) +
  geom_sf(data = jittered, size = .75, 
          color = "#206D2A") +
  theme_void()

cowplot::ggdraw() +
  cowplot::draw_plot(
    facet_1 +
      geom_rect(aes(xmin = sf::st_bbox(cooper_boone_tiles)['xmin'] + 31000, 
                    xmax = sf::st_bbox(cooper_boone_tiles)['xmax'] - 29250, 
                    ymin = sf::st_bbox(cooper_boone_tiles)['ymin'] + 28000, 
                    ymax = sf::st_bbox(cooper_boone_tiles)['ymax'] - 39000), color = "black", fill = NA, linetype = 2), 
    -.313, 0, 1, 1, scale = .4) +
  cowplot::draw_plot(
    facet_2 + 
      theme(panel.border = element_rect(colour = "black", fill=NA, size=1.75, linetype = 1)), 
    0, 0.033, 1, 1, scale = .33) +
  cowplot::draw_plot(
    facet_3 + 
      geom_rect(aes(xmin = sf::st_bbox(cooper_boone_tiles)['xmin'] + 31000, 
                    xmax = sf::st_bbox(cooper_boone_tiles)['xmax'] - 29250, 
                    ymin = sf::st_bbox(cooper_boone_tiles)['ymin'] + 28000, 
                    ymax = sf::st_bbox(cooper_boone_tiles)['ymax'] - 39000), color = "black", fill = NA, linetype = 2) +
      theme(legend.position = "none"), 
    .313, 0, 1, 1, scale = .4)

PPR_legend_for_illustrator <- ggplot() +
  ggpattern::geom_sf_pattern(
    data = bind_cols(acs_cooper_boone_counties,
                     PPR = c("0", "57.6")),
    aes(fill = PPR),
    pattern_colour = "grey60",
    pattern_spacing = 0.01,
    pattern_density = 0.02,
    pattern_angle = -45,
    pattern = "stripe",
    width = .02,
    alpha = 0.5,
    color = "grey30",
    size = .5) +
  scale_fill_manual(values = c("#206D2A", "#FFEEA1"),
                    guide = guide_legend(reverse = TRUE)) +
  theme_void() +
  theme(text = element_text(size=5, family = "IBM Plex Sans Light"),
        legend.key.size = unit(1,"line"),
        legend.position="bottom",
        legend.spacing.x = unit(0.5, 'line'))

PPR_legend_for_illustrator <- ggpubr::get_legend(PPR_legend_for_illustrator) %>% 
  ggpubr::as_ggplot()

legend_for_illustrator_3SFCA <- facet_3 + 
  theme(legend.position = "bottom") +
  theme(text = element_text(size = 5, family = "IBM Plex Sans Light"),
        legend.key.size = unit(1,"line"),
        legend.position="bottom",
        legend.spacing.x = unit(0.5, 'line')) +
  labs(fill = "3SFCA")

legend_for_illustrator_3SFCA <- ggpubr::get_legend(legend_for_illustrator_3SFCA) %>% 
  ggpubr::as_ggplot()

rm(facet_1, facet_2, facet_3, cooper, boone, cooper_boone_tiles, jittered, legend_for_illustrator_3SFCA, plot_for_illustrator, points, PPR_legend_for_illustrator, psychiatrists, acs_cooper_boone_counties, acs_cooper_boone_tracts, acs_cooper_tracts, travel_matrix)

# r bivariate models
simple_model_availability_psychiatrist <- fixest::feglm(suicide_rate ~ psychiatrist_availaibility,
                                                        weights = ~total_pop,
                                                        family = "binomial",
                                                        data = access_df)

simple_model_accessibility_psychiatrist <- fixest::feglm(suicide_rate ~ psychiatrist_general_tract_access,
                                                        weights = ~total_pop,
                                                        family = "binomial",
                                                        data = access_df)

rm(simple_model_accessibility_psychiatrist, simple_model_availability_psychiatrist)

# state-SE clustered models
access_df$psychiatrist_availaibility_std <- scale(access_df$psychiatrist_availaibility)
access_df$therapist_availability_std <- scale(access_df$therapist_availability)

suicide_psychiatrist_availability_clustered_model <-
  fixest::feglm(
    suicide_rate ~ psychiatrist_availaibility,
    cluster = ~state,
    weights = ~total_pop,
    family = binomial(),
  data = access_df)

suicide_psychiatrist_availability_std_clustered_model <-
  fixest::feglm(
    suicide_rate ~ psychiatrist_availaibility_std,
    cluster = ~state,
    weights = ~total_pop,
    family = binomial(),
  data = access_df)

suicide_therapist_availability_clustered_model <-
  fixest::feglm(
    suicide_rate ~ therapist_availability,
    cluster = ~state,
    weights = ~total_pop,
    family = binomial,
  data = access_df)

suicide_therapist_availability_std_clustered_model <-
  fixest::feglm(
    suicide_rate ~ therapist_availability_std,
    cluster = ~state,
    weights = ~total_pop,
    family = binomial,
  data = access_df)

suicide_psychiatrist_accessibility_clustered_model <-
  fixest::feglm(
    suicide_rate ~ psychiatrist_general_tract_access,
    cluster = ~state,
    weights = ~total_pop,
    family = binomial,
  data = access_df)

suicide_therapist_accessibility_clustered_model <-
  fixest::feglm(
    suicide_rate ~ therapist_general_tract_access,
    cluster = ~state,
    weights = ~total_pop,
    family = binomial,
  data = access_df)

# comparing model fit
temp_suicide_psychiatrist_accessibility_model_glm <-
  glm(
    suicide_rate ~ psychiatrist_general_tract_access,
    weights = total_pop,
    family = "binomial",
    data = access_df)

temp_suicide_psychiatrist_availability_model_glm <-
  glm(
    suicide_rate ~ psychiatrist_availaibility,
    weights = total_pop,
    family = "binomial",
    data = access_df)

temp_pseudo_r2_psychiatrist_accessibility <- rcompanion::nagelkerke(temp_suicide_psychiatrist_accessibility_model_glm)
temp_pseudo_r2_psychiatrist_accessibility <- temp_pseudo_r2_psychiatrist_accessibility$Pseudo.R.squared.for.model.vs.null %>% 
  as.data.frame() %>% 
  rownames_to_column() %>% 
  rename(r2_accessibility = Pseudo.R.squared)

temp_pseudo_r2_psychiatrist_availability <- rcompanion::nagelkerke(temp_suicide_psychiatrist_availability_model_glm)
temp_pseudo_r2_psychiatrist_availability <- temp_pseudo_r2_psychiatrist_availability$Pseudo.R.squared.for.model.vs.null %>% 
  as.data.frame() %>% 
  rownames_to_column() %>% 
  rename(r2_availability = Pseudo.R.squared)

psychiatrist_pseudo_r2 <- inner_join(temp_pseudo_r2_psychiatrist_availability, 
                                     temp_pseudo_r2_psychiatrist_accessibility) %>% 
  mutate(across(is.numeric, round, 2))

rm(temp_pseudo_r2_psychiatrist_accessibility, temp_pseudo_r2_psychiatrist_availability, temp_suicide_psychiatrist_accessibility_model_glm, temp_suicide_psychiatrist_availability_model_glm)

temp_suicide_therapist_accessibility_model_glm <-
  glm(
    suicide_rate ~ therapist_general_tract_access,
    weights = total_pop,
    family = "binomial",
    data = access_df)

temp_suicide_therapist_availability_model_glm <-
  glm(
    suicide_rate ~ therapist_availability,
    weights = total_pop,
    family = "binomial",
    data = access_df)

temp_pseudo_r2_ptherapist_accessibility <- rcompanion::nagelkerke(temp_suicide_therapist_accessibility_model_glm)
temp_pseudo_r2_ptherapist_accessibility <- temp_pseudo_r2_ptherapist_accessibility$Pseudo.R.squared.for.model.vs.null %>% 
  as.data.frame() %>% 
  rownames_to_column() %>% 
  rename(r2_accessibility = Pseudo.R.squared)

temp_pseudo_r2_therapist_availability <- rcompanion::nagelkerke(temp_suicide_therapist_availability_model_glm)
temp_pseudo_r2_therapist_availability <- temp_pseudo_r2_therapist_availability$Pseudo.R.squared.for.model.vs.null %>% 
  as.data.frame() %>% 
  rownames_to_column() %>% 
  rename(r2_availability = Pseudo.R.squared)

therapist_pseudo_r2 <- inner_join(temp_pseudo_r2_therapist_availability, 
                                  temp_pseudo_r2_ptherapist_accessibility) %>% 
  mutate(across(is.numeric, round, 2))

rm(temp_pseudo_r2_ptherapist_accessibility, temp_pseudo_r2_therapist_availability, temp_suicide_therapist_accessibility_model_glm, temp_suicide_therapist_availability_model_glm, 
   suicide_psychiatrist_accessibility_clustered_model, suicide_therapist_accessibility_clustered_model,
   suicide_psychiatrist_availability_clustered_model, suicide_psychiatrist_availability_std_clustered_model,
   suicide_therapist_availability_clustered_model, suicide_therapist_availability_std_clustered_model,
   psychiatrist_pseudo_r2, therapist_pseudo_r2)

# PPR and accessibility for psychiatrists + psychotherapists
suicide_psychiatrist_and_therapist_availability_clustered_model <-
  fixest::feglm(
    suicide_rate ~ psychiatrist_availaibility_std + therapist_availability_std,
    cluster = ~state,
    weights = ~total_pop,
    familty = binomial,
  data = access_df)

suicide_psychiatrist_and_therapist_accessibility_clustered_model <-
  fixest::feglm(
    suicide_rate ~ psychiatrist_general_tract_access + therapist_general_tract_access,
    cluster = ~state,
    weights = ~total_pop,
    familty = binomial,
  data = access_df)

# plotting
access_df %>% 
  filter(!is.na(psychiatrist_availaibility)) %>% 
  mutate(psychiatrist_availaibility_scaled = corpcor::wt.scale(psychiatrist_availaibility, total_pop)) %>%
  pivot_longer(c(psychiatrist_availaibility_scaled, psychiatrist_general_tract_access)) %>% 
  rename(method = name) %>% 
  mutate(method = ifelse(method == "psychiatrist_availaibility_scaled", "PPR", "3SFCA"),
         method = factor(method, levels = c("PPR", "3SFCA"))) %>% 
  ggplot(aes(x = value, y = log(suicide_rate), size = total_pop / 2)) +
  facet_wrap(~method, scales = "free_x") +
  geom_point(shape = 1, alpha = .2) +
  geom_smooth(method = "lm",
              se = FALSE,
              color = "grey20",
              size = .35) +
  labs(x = "Psychiatrist accessibility (standardized)",
       y = "Log suicide rate") +
  theme_minimal() +
  theme(legend.position='none',
        text = element_text(family = "IBM Plex Sans Light"),
        panel.spacing.x = unit(2.5, "lines"),
        panel.grid.minor = element_blank(),
        axis.title.x = element_text(vjust = -1),
        axis.title.y = element_text(vjust = 1))

access_df %>% 
  filter(!is.na(therapist_availability)) %>% 
  mutate(therapist_availability_scaled = corpcor::wt.scale(therapist_availability, total_pop)) %>%
  pivot_longer(c(therapist_availability_scaled, therapist_general_tract_access)) %>% 
  rename(method = name) %>% 
  mutate(method = ifelse(method == "therapist_availability_scaled", "PPR", "3SFCA"),
         method = factor(method, levels = c("PPR", "3SFCA"))) %>% 
  ggplot(aes(x = value, y = log(suicide_rate), size = total_pop)) +
  facet_wrap(~method, scales = "free_x") +
  geom_point(shape = 1, alpha = .2) +
  geom_smooth(method = "lm",
              se = FALSE,
              color = "grey20",
              size = .35) +
  labs(x = "Psychotherapist accessibility (standardized)",
       y = "Log suicide rate") +
  theme_minimal() +
  theme(legend.position='none',
        strip.text = element_text(size = 14),
        text = element_text(family = "IBM Plex Sans"),
        axis.text = element_text(size = 11),
        panel.spacing.x = unit(2.5, "lines"),
        panel.grid.minor = element_blank(),
        axis.title.x = element_text(vjust = -1, size = 14),
        axis.title.y = element_text(vjust = 1, size = 14))

# mapping bivariate shading maps
mapping_df <- access_df %>% 
  select(county_code, suicide_rate, total_pop, psychiatrist_general_tract_access, therapist_general_tract_access,
         psychiatrist_availaibility, therapist_availability)

mapping_df <- create_quantile_column_function(df = mapping_df, variable = suicide_rate, n = 3) %>% 
  rename(suicide_quantile = quintile)

mapping_df <- create_quantile_column_function(df = mapping_df, variable = psychiatrist_general_tract_access, n = 3) %>% 
  rename(psychiatrist_accessibility_quantile = quintile)

mapping_df <- create_quantile_column_function(df = mapping_df, variable = therapist_general_tract_access, n = 3) %>% 
  rename(therapist_accessibility_quantile = quintile)

# inspired by https://timogrossenbacher.ch/2019/04/bivariate-maps-with-ggplot2-and-sf/
bivariate_legend <- tibble(
  "3 - 3" = "#3F2949",
  "2 - 3" = "#435786",
  "1 - 3" = "#4885C1",
  "3 - 2" = "#77324C",
  "2 - 2" = "#806A8A",
  "1 - 2" = "#89A1C8",
  "3 - 1" = "#AE3A4E",
  "2 - 1" = "#BC7C8F",
  "1 - 1" = "#CABED0" 
) %>%
  gather("bivariate_group", "bivariate_fill") %>% 
  separate(bivariate_group, into = c("suicide_quantile", "accessibility_quantile"), sep = " - ", remove = FALSE) %>% 
  mutate(across(matches("quantile"), as.numeric))

mapping_df_psychiatrists <- mapping_df %>% 
  mutate(bivariate_group_psychiatrists = 
           ifelse(is.na(suicide_quantile) | is.na(psychiatrist_accessibility_quantile), 
                  NA, 
                  paste0(suicide_quantile, " - ", psychiatrist_accessibility_quantile))) %>% 
  left_join(bivariate_legend, by = c("bivariate_group_psychiatrists" = "bivariate_group"))

mapping_df_therapists <- mapping_df %>% 
  mutate(bivariate_group_therapists = 
           ifelse(is.na(suicide_quantile) | is.na(therapist_accessibility_quantile), 
                  NA, 
                  paste0(suicide_quantile, " - ", therapist_accessibility_quantile))) %>% 
  left_join(bivariate_legend, by = c("bivariate_group_therapists" = "bivariate_group"))

urbn_counties_psychiatrists <- left_join(mapping_df_psychiatrists, 
                                         urbnmapr::counties, by = c("county_code" =  "county_fips")) 

urbn_counties_therapists <- left_join(mapping_df_therapists, 
                                      urbnmapr::counties, by = c("county_code" =  "county_fips")) 

legend_object <- bivariate_legend %>% 
  mutate(suicide_quantile = as.integer(suicide_quantile),
         accessibility_quantile = as.integer(accessibility_quantile)) %>% 
  ggplot() +
  geom_tile(
    mapping = aes(x = suicide_quantile, y = accessibility_quantile, fill = bivariate_fill)) +
  scale_fill_identity() +
  labs(x = "Higher suicide rate →",
       y = "Higher accessibility →") +
  cowplot::theme_map() +
  theme(text = element_text(family = "IBM Plex Sans Light"),
        axis.title = element_text(size = 10.5),
        axis.title.y = element_text(angle = 90)) +
  coord_fixed()

missing_counties <- urbn_counties_psychiatrists %>% 
  filter(is.na(suicide_rate)) %>% 
  pull(county_code) %>% 
  unique

missing_counties_shape <- urbnmapr::counties %>% 
  filter(county_fips %in% missing_counties)

bivariate_map_psychiatrists_missing_counties_stripes <- urbn_counties_psychiatrists %>% 
  ggplot(aes(long, lat, group = group, fill = bivariate_fill), interpolate = TRUE) +
  geom_polygon(color = NA, size = 1) +
  coord_map(
    projection = "albers",
    lat0 = 39, lat1 = 45) +
  scale_fill_identity() +
  theme_void() +
  ggpattern::geom_polygon_pattern(data = missing_counties_shape,
                                  aes(x = long, y = lat, group = group, fill = NULL),
                                  pattern_colour = "grey60",
                                  alpha = .5,
                                  fill = "grey60",
                                  pattern_spacing = 0.01,
                                  pattern_density = 0.01,
                                  pattern_angle = -45,
                                  pattern = "stripe",
                                  width = .02,
                                  color = "gray30",
                                  size = 0.025
  ) 

cowplot::ggdraw() +
  cowplot::draw_plot(bivariate_map_psychiatrists_missing_counties_stripes, 0, 0, 1, 1, scale = 1.1) +
  cowplot::draw_plot(legend_object, 0.85, 0.44, 0.15, 0.15, scale = 1)

missing_states <- urbn_counties_therapists %>% 
  filter(is.na(therapist_availability)) %>% 
  mutate(state = str_extract(county_code, "^\\d\\d")) %>% 
  pull(state) %>% 
  unique

missing_states_shape <- urbnmapr::states %>% 
  filter(state_fips %in% missing_states)

missing_counties <- urbn_counties_therapists %>% 
  filter(is.na(suicide_rate)) %>% 
  filter(!str_extract(county_code, "^\\d\\d") %in% missing_states) %>% 
  pull(county_code) %>% 
  unique

missing_counties_shape <- urbnmapr::counties %>% 
  filter(county_fips %in% missing_counties)

bivariate_map_therapists_no_missing_counties <- urbn_counties_therapists %>% 
  filter(!str_extract(county_code, "^\\d\\d") %in% missing_states) %>% 
  ggplot(aes(long, lat, group = group, fill = bivariate_fill), interpolate = TRUE) +
  geom_polygon(color = NA, size = 1) +
  coord_map(
    projection = "albers",
    lat0 = 39, lat1 = 45) +
  scale_fill_identity() +
  theme_void() +
  ggpattern::geom_polygon_pattern(data = missing_states_shape,
                                  aes(x = long, y = lat, group = group, fill = NULL),
                                  pattern_colour = "grey60",
                                  alpha = .5,
                                  fill = "grey60",
                                  pattern_spacing = 0.01,
                                  pattern_density = 0.01,
                                  pattern_angle = -45,
                                  pattern = "stripe",
                                  width = .02,
                                  color = "gray30",
                                  size = 0.15
  ) +
  ggpattern::geom_polygon_pattern(data = missing_counties_shape,
                                  aes(x = long, y = lat, group = group, fill = NULL),
                                  pattern_colour = "grey60",
                                  alpha = .5,
                                  fill = "grey60",
                                  pattern_spacing = 0.01,
                                  pattern_density = 0.01,
                                  pattern_angle = -45,
                                  pattern = "stripe",
                                  width = .02,
                                  color = "gray30",
                                  size = 0.025
  ) 

cowplot::ggdraw() +
  cowplot::draw_plot(bivariate_map_therapists_no_missing_counties, 0, 0, 1, 1, scale = 1.1) +
  cowplot::draw_plot(legend_object, 0.85, 0.44, 0.15, 0.15, scale = 1)

rm(bivariate_legend, bivariate_map_psychiatrists, bivariate_map_psychiatrists_missing_counties_stripes, bivariate_map_therapists, bivariate_map_therapists_no_missing_counties, legend_object, mapping_df, mapping_df_psychiatrists, mapping_df_therapists, missing_counties, missing_counties_shape, missing_states, missing_states_shape, urbn_counties_psychiatrists, urbn_counties_therapists, final_plot_psychiatrists, final_plot_therapists)

# accessibility and PPR lasso
temp_df <- access_df[!is.na(access_df$suicide_rate), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_community_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_institutional_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_family_unity), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_collective_efficacy), ]

temp_df <- temp_df %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) 

temp_df_psychiatrist <- temp_df %>% 
  filter(!is.na(psychiatrist_general_tract_access),
         !is.na(psychiatrist_availaibility))

temp_df_therapist <- temp_df %>% 
  filter(!is.na(therapist_general_tract_access),
         !is.na(therapist_availability))

temp_df_all_providers <- temp_df %>% 
  filter(!is.na(psychiatrist_general_tract_access),
         !is.na(psychiatrist_availaibility),
         !is.na(therapist_general_tract_access),
         !is.na(therapist_availability))

confounder_variables <- temp_df_psychiatrist[, c(
  "psychiatrist_general_tract_access",
  "psychiatrist_availaibility",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- matrix(c(temp_df_psychiatrist$alive, temp_df_psychiatrist$dead), ncol = 2) 
weights <- temp_df_psychiatrist$total_pop

cvfit <- cv.glmnet(x = confounder_variables, 
                   y = outcome, 
                   weights = weights,
                   family = c("binomial"), 
                   alpha = 1,
                   type.measure = "mse",
                   nfolds = 10)

lasso_psychiatrist <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_psychiatrist <- bind_rows(
  tibble(
    rowname = lasso_psychiatrist$beta@Dimnames[[1]][as.list(lasso_psychiatrist$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_psychiatrist$beta@Dimnames[[1]][as.list(lasso_psychiatrist$beta) == 0],
    lasso_keep = FALSE)
)

rm(cvfit, weights, outcome, confounder_variables, temp_df_psychiatrist)

confounder_variables <- temp_df_therapist[, c(
  "therapist_general_tract_access",
  "therapist_availability",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- matrix(c(temp_df_therapist$alive, temp_df_therapist$dead), ncol = 2) 
weights <- temp_df_therapist$total_pop

cvfit <- cv.glmnet(x = confounder_variables, 
                   y = outcome, 
                   weights = weights,
                   family = c("binomial"), 
                   alpha = 1,
                   type.measure = "mse",
                   nfolds = 10)

lasso_therapist <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_therapist <- bind_rows(
  tibble(
    rowname = lasso_therapist$beta@Dimnames[[1]][as.list(lasso_therapist$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_therapist$beta@Dimnames[[1]][as.list(lasso_therapist$beta) == 0],
    lasso_keep = FALSE)
)

rm(cvfit, weights, outcome, confounder_variables, temp_df_therapist)

confounder_variables <- temp_df_all_providers[, c(
  "psychiatrist_general_tract_access",
  "therapist_general_tract_access",
  "psychiatrist_availaibility",
  "therapist_availability",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- matrix(c(temp_df_all_providers$alive, temp_df_all_providers$dead), ncol = 2) 
weights <- temp_df_all_providers$total_pop

cvfit <- cv.glmnet(x = confounder_variables, 
                   y = outcome, 
                   weights = weights,
                   family = c("binomial"), 
                   alpha = 1,
                   type.measure = "mse",
                   nfolds = 10)

lasso_all_providers <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_all_providers <- bind_rows(
  tibble(
    rowname = lasso_all_providers$beta@Dimnames[[1]][as.list(lasso_all_providers$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_all_providers$beta@Dimnames[[1]][as.list(lasso_all_providers$beta) == 0],
    lasso_keep = FALSE)
)

rm(cvfit, weights, outcome, confounder_variables, temp_df_all_providers)

# table
three_lassos_gt_df <- bind_rows(
  data.frame(term = lasso_psychiatrist$beta@Dimnames[[1]],
             b = lasso_psychiatrist$beta %>% as.numeric(),
             model = "psychiatrists"),
  data.frame(term = lasso_therapist$beta@Dimnames[[1]],
             b = lasso_therapist$beta %>% as.numeric(),
             model = "therapists"),
  data.frame(term = lasso_all_providers$beta@Dimnames[[1]],
             b = lasso_all_providers$beta %>% as.numeric(),
             model = "all_providers")) %>% 
  pivot_wider(names_from = model, values_from = b) %>% 
  mutate(across(is.numeric, round, 3))

three_lassos_gt_df %>% 
  fix_terms() %>% 
  factorize_terms() %>% 
  gt(rowname_col = "term") %>% 
  tab_header(title = md(paste0("**Table SX. Logistic Lasso Regressions of the Correlates of County-level Suicide Risk**"))) %>% 
  cols_label(
    psychiatrists = "Psychiatrist access", 
    therapists = "Psychotherapist access",
    all_providers = "All providers") %>% 
  tab_options(table.font.siz = pct(90)) %>% 
  fmt_missing(columns = everything(), missing_text = "...") %>%
  tab_footnote(
    footnote = "Covariates standardized. Coefficients presented as log odds.",
    locations = cells_title(groups = "title")) %>% 
  tab_footnote(
    footnote = paste0("N=", lasso_psychiatrist$nobs %>% prettify),
    locations = cells_column_labels(columns = psychiatrists)) %>% 
  tab_footnote(
    footnote = paste0("N=", lasso_therapist$nobs %>% prettify),
    locations = cells_column_labels(columns = therapists)) %>% 
  tab_footnote(
    footnote = paste0("N=", lasso_all_providers$nobs %>% prettify),
    locations = cells_column_labels(columns = all_providers)) 

rm(lasso_psychiatrist, lasso_therapist, lasso_all_providers)

# covariates
covariates_string <- "+ rurality_1_to_10 + pop_density_1k_ppl_per_sq_mile + separated_or_divorced_in_10_pct + pct_born_in_the_usa_in_10_pct + insurance_rate_in_10_pct + unemployment_rate_in_10_pct + median_age + males_in_10_pct + poverty_in_10_pct + ADI_NATRANK + ba_degree_over_25_prop_in_10_pct + med_household_income_in_10K + pop_white_non_hispanic_in_10_pct + pop_black_non_hispanic_in_10_pct + pop_asian_non_hispanic_in_10_pct + pop_hispanic_all_races_in_10_pct + soc_capital_community_health + soc_capital_collective_efficacy + soc_capital_family_unity + soc_capital_institutional_health + liquor_and_drinking_ratio + gun_store_ratio"
covariates <- str_split(covariates_string, "\\+") %>% map(str_trim) %>% unlist
covariates <- covariates[covariates!=""]

covariates <- c(covariates, "psychiatrist_availaibility", "therapist_availability")
covariates <- covariates[!str_detect(covariates, "gun_store_ratio|liquor_and_drinking_ratio")]

access_df_std <- access_df[ , covariates] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) 

access_df_std <- bind_cols(access_df_std,
                           access_df %>% select(suicide_rate, total_pop, gun_store_ratio, liquor_and_drinking_ratio,
                                                psychiatrist_general_tract_access,
                                                therapist_general_tract_access))

covariates <- c(covariates, "psychiatrist_general_tract_access", "therapist_general_tract_access", "gun_store_ratio", "liquor_and_drinking_ratio")

bivariate_df <- tibble(term = NA, 
                       b=NA,
                       se=NA,
                       conf.low=NA,
                       conf.high=NA,
                       p=NA,
                       n=NA)

for (i in 1:length(covariates)) {
  
  temp_bivariate_formula <- as.formula(paste0("suicide_rate ~ ", covariates[i]))
  temp_bivariate_regression <- fixest::feglm(temp_bivariate_formula,
                                             weights = ~total_pop,
                                             family = "binomial",
                                             data = access_df_std)
  
  temp_tidy <- broom::tidy(temp_bivariate_regression, conf.int = TRUE) %>% 
    mutate(estimate = exp(estimate),
           conf.low = exp(conf.low),
           conf.high = exp(conf.high))
  
  bivariate_df[i, ] <- tibble(temp_tidy[2, 'term'],
                              temp_tidy[2, 'estimate'],
                              temp_tidy[2, 'std.error'],
                              temp_tidy[2, 'conf.low'],
                              temp_tidy[2, 'conf.high'],
                              temp_tidy[2, 'p.value'],
                              nobs(temp_bivariate_regression))
}

bivariate_df <- bivariate_df %>% 
  filter(term != "(Intercept)") %>% 
  fix_terms()

bivariate_df_temp <- bivariate_df %>% 
  add_row(term = "") %>% 
  factorize_terms() %>% 
  mutate(p = map(p, adjust_p, FALSE) %>% unlist) %>% 
  mutate(significance = ifelse(p == "< .001", 0, as.numeric(p)),
         significance = case_when(significance == 0 ~ "",
                                  significance < .01 ~ "††",
                                  significance < .05 ~ "†",
                                  significance >= .05 ~ "‡"))

bivariate_df_temp %>% 
  ggplot(aes(x = fct_rev(term), y = b, ymin = conf.low, ymax = conf.high, label = significance)) +
  geom_point(size = 2.25) +
  geom_errorbar(width=.125, linetype = 1) +
  geom_text(aes(x = term, y = conf.low - .02), size = 2.25, color = "black") +
  labs(x=NULL, y = "Suicide Risk Ratio",
       caption = "All covariates standardized") +
  geom_hline(yintercept=1, color='black', linetype='dashed', alpha=.35) +
  geom_vline(xintercept=23, color='black', linetype='dashed', alpha=.35) +
  scale_y_continuous(breaks = seq(0, 4, .1),
                     limits = c(.65, 1.35)) +
  theme_classic(base_size=9) +
  scale_colour_brewer(palette = "Set1") +
  coord_flip(ylim = c(NA, NA)) +
  theme(
    text = element_text(family = "IBM Plex Sans Light"),
    axis.text.y = element_text(
      color = ifelse(str_detect(bivariate_df_temp$term, "PPR|accessibility"), "black", "black"),
      size = ifelse(str_detect(bivariate_df_temp$term, "PPR|accessibility"), 9, 9),
      face = ifelse(str_detect(bivariate_df_temp$term, "PPR|accessibility"), "plain", "plain")),
    axis.title.x = element_text(vjust = -.25, size = 8),
    plot.caption = element_text(vjust = -1))

# data for forest plot
df_blobbogram2 <- bivariate_df %>% 
  filter(str_detect(term, "access")) %>% 
  mutate(type = "bivariate")

# table  
bivariate_df %>% 
  factorize_terms() %>% 
  mutate(p = map(p, adjust_p, FALSE) %>% unlist) %>% 
  mutate(across(is.numeric, round, 3)) %>% 
  mutate(CI = paste0(conf.low, " to ", conf.high)) %>%
  select(term, b, se, CI, p) %>% 
  gt(rowname_col = "term") %>% 
  tab_header(title = md(paste0("**Table SX. Logistic Bivariate Correlates of County-level Suicide Risk**"))) %>% 
  cols_label(
    b = "RR",
    se = "SE",
    CI = "95% CI",
    p	= md("_p_ Value")
  ) %>% 
  tab_options(table.font.siz = pct(90)) %>% 
  fmt_missing(columns = everything(), missing_text = "...") %>%
  tab_style(style = list(
    cell_borders(sides = 'right', style = 'solid', color = "grey90", weight = px(1.5))),
    locations = cells_body(columns = matches("^p."))) %>% 
  tab_footnote(
    footnote = "Covariates standardized.",
    locations = cells_title(groups = "title")) 

# multiple regression
suicide_glm_psychiatrist_accessibility <- fixest::feglm(
  as.formula(paste0("suicide_rate ~ psychiatrist_general_tract_access ", covariates_string)),
  family = "binomial",
  weights = ~total_pop,
  cluster = ~state,
  data = access_df
) %>% 
  broom::tidy(conf.int = TRUE) %>% 
  mutate(across(matches("estimate|conf"), exp))

suicide_glm_therapist_accessibility <- fixest::feglm(
  as.formula(paste0("suicide_rate ~ therapist_general_tract_access ", covariates_string)),
  family = "binomial",
  weights = ~total_pop,
  cluster = ~state,
  data = access_df
) %>% 
  broom::tidy(conf.int = TRUE) %>% 
  mutate(across(matches("estimate|conf"), exp))

# data for forest plot
df_blobbogram2 <- bind_rows(
  
  df_blobbogram2,
  
  suicide_glm_psychiatrist_accessibility %>% 
    filter(term == "psychiatrist_general_tract_access") %>% 
    select(term,
           b = estimate,
           p = p.value,
           conf.low,
           conf.high) %>% 
    mutate(type = "multivariate",
           term = "Psychiatrist accessibility"),
  
  suicide_glm_therapist_accessibility %>% 
    filter(term == "therapist_general_tract_access") %>% 
    select(term,
           b = estimate,
           p = p.value,
           conf.low,
           conf.high) %>% 
    mutate(type = "multivariate",
           term = "Psychotherapist accessibility")
)

# double lasso
temp_df <- access_df[!is.na(access_df$suicide_rate), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_community_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_institutional_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_family_unity), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_collective_efficacy), ]

temp_df <- temp_df %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) %>% 
  pivot_longer(dead:alive, names_to = "dead_x") %>% 
  rename(dead = dead_x) %>% 
  mutate(dead = ifelse(dead == "dead", 1, 0)) %>% 
  filter(value > 0) 

temp_df_psychiatrist <- temp_df %>% 
  filter(!is.na(psychiatrist_general_tract_access))

confounder_variables <- temp_df_psychiatrist[, c(
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- pull(temp_df_psychiatrist, dead)
outcome <- ifelse(outcome == 1, TRUE, FALSE) 
weights <- pull(temp_df_psychiatrist, value)
treatment <- pull(temp_df_psychiatrist, psychiatrist_general_tract_access)
x <- bind_cols(confounder_variables, outcome = outcome, weights = weights, treatment = treatment)
x <- uncount(x, weights = weights) 
outcome <- pull(x, outcome)
treatment <- pull(x, treatment)
x.matrix <- as.matrix(x %>% select(-outcome, -treatment))
rm(x)

lasso <- hdm::rlassologit(x = x.matrix,
                          y = outcome)

lasso_keep_1 <- as.data.frame(lasso$beta) %>%
  rownames_to_column() %>%
  janitor::clean_names() %>% 
  mutate(lasso_beta = lasso_beta != 0) %>% 
  rename(lasso_keep = lasso_beta)

temp_df <- access_df[!is.na(access_df$suicide_rate), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_community_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_institutional_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_family_unity), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_collective_efficacy), ]

temp_df_psychiatrist <- temp_df %>% 
  filter(!is.na(psychiatrist_general_tract_access))

confounder_variables <- temp_df_psychiatrist[, c(
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

treatment <- pull(temp_df_psychiatrist, psychiatrist_general_tract_access)

hdm.accessibility.lasso <- hdm::rlasso(x = confounder_variables, 
                                       y = treatment)

lasso_keep_2 <- as.data.frame(hdm.accessibility.lasso$coefficients) %>%
  rownames_to_column() %>% 
  rename(lasso_keep = `hdm.accessibility.lasso$coefficients`) %>% 
  mutate(lasso_keep = lasso_keep != 0) %>% 
  filter(rowname != "(Intercept)")

temp_double_lasso_formula_psychiatrist_accessibility <- as.formula(paste0("suicide_rate ~ psychiatrist_general_tract_access + ", bind_rows(lasso_keep_1, lasso_keep_2) %>% filter(lasso_keep) %>% distinct %>% summarize(x = paste0(rowname, collapse = " + "))))

temp_double_lasso_regression <- glm(temp_double_lasso_formula_psychiatrist_accessibility,
                                    weights = total_pop,
                                    family = "binomial",
                                    data = access_df_std) 

# data for forest plot
df_blobbogram2 <- bind_rows(
  df_blobbogram2,
  
  broom::tidy(temp_double_lasso_regression, conf.int = TRUE) %>% 
    filter(term == "psychiatrist_general_tract_access") %>% 
    mutate(across(matches("estimate|conf"), exp)) %>% 
    select(term,
           b = estimate,
           se = std.error,
           p = p.value,
           conf.low, conf.high) %>% 
    mutate(type = "double_lasso",
           term = "Psychiatrist accessibility")
)

# accessibility gaps
temp_deciles_accessibility <- access_df %>% 
  summarize(psychiatrist_general_tract_access = 
              Hmisc::wtd.quantile(psychiatrist_general_tract_access, probs = c(.1, .9), weights = total_pop, na.rm = TRUE)) %>% 
  pull %>% 
  as.numeric()

# spatial autocorrelation
county_shp <- sf::st_read(here("data", "cb_2018_us_county_5m", "cb_2018_us_county_5m.shp"))

access_df_for_spatial_regression <- 
  access_df[complete.cases(access_df %>% 
                             select(county_code, psychiatrist_general_tract_access, 
                                    suicide_rate)), ]

variables_to_keep <-  bind_rows(lasso_keep_1, lasso_keep_2) %>% 
  filter(lasso_keep) %>% 
  distinct %>% 
  pull(rowname)

access_df_for_spatial_regression <- access_df_for_spatial_regression[
  access_df_for_spatial_regression %>% 
    select(matches(variables_to_keep)) %>% 
    complete.cases(), ]

good_counties <- access_df_for_spatial_regression %>%
  pull(county_code) %>%
  unique

county_shp <- county_shp %>%
  filter(GEOID %in% good_counties)

access_df_for_spatial_regression <- access_df_for_spatial_regression %>%
  filter(county_code %in% (county_shp %>% pull(GEOID) %>% unique))

list.queen <- poly2nb(county_shp, queen=TRUE)
rwm <- nb2listw(list.queen, style="B", zero.policy=TRUE)

add_nb <- function(x){
  
  queen_nb <- poly2nb(x, queen = TRUE)
  
  count = card(queen_nb)
  if(!any(count==0)){
    return(queen_nb)
  }
  
  nnbs = knearneigh(st_coordinates(st_centroid(x)))$nn
  
  no_edges_from = which(count==0)
  for(i in no_edges_from){
    queen_nb[[i]] = nnbs[i]
  }
  return(queen_nb)
}

new_queen_nb <- add_nb(county_shp)
W <- nb2listw(new_queen_nb, style="B", zero.policy=TRUE)
wm <- nb2mat(new_queen_nb, style = "B", zero.policy = TRUE)
rwm <- mat2listw(wm, style = "B")

morans_function <- function(glm_formula, df){
  
  glm.model <- fixest::feglm(glm_formula,
                             cluster = ~state,
                             weights = ~total_pop,
                             data = df)
  
  moran.lm <- moran.test(residuals(glm.model), rwm, alternative="two.sided", zero.policy = TRUE)
  moran.mc.object <- moran.mc(x=residuals(glm.model), listw=rwm, nsim=10000)
  
  return(list(moran.lm, moran.mc.object))
  
}

morans_psychiatrist_post_double_lasso <- morans_function(temp_double_lasso_formula_psychiatrist_accessibility, access_df_for_spatial_regression)
morans_psychiatrist_accessibility_bivariate <- morans_function(as.formula("suicide_rate ~ psychiatrist_general_tract_access"), access_df_for_spatial_regression)

# spatial regression
wm2 <- wm
wm2 <- miscTools::symMatrix(wm2[lower.tri(wm2, TRUE)], nrow=nrow(wm2), byrow=TRUE)
islands <- NULL
for (i in 1:dim(wm2)[2]){
  if (sum(wm2[i ,]) == 0) islands <- c(islands, i)
}
wm2 <- wm2[-islands, -islands]
access_df_for_spatial_regression <- access_df_for_spatial_regression[-islands, ]

set.seed(1)
chain1_bivariate <- CARBayes::S.CARleroux(
  formula = as.formula("suicide_rate ~ psychiatrist_general_tract_access"),
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

set.seed(2)
chain2_bivariate <- CARBayes::S.CARleroux(
  formula = as.formula("suicide_rate ~ psychiatrist_general_tract_access"),
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

set.seed(3)
chain3_bivariate <- CARBayes::S.CARleroux(
  formula = as.formula("suicide_rate ~ psychiatrist_general_tract_access"),
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

set.seed(4)
chain4_bivariate <- CARBayes::S.CARleroux(
  formula = as.formula("suicide_rate ~ psychiatrist_general_tract_access"),
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

beta.samples.matrix_bivariate <- rbind(chain1_bivariate$samples$beta, 
                                       chain2_bivariate$samples$beta, 
                                       chain3_bivariate$samples$beta,
                                       chain4_bivariate$samples$beta)
colnames(beta.samples.matrix_bivariate) <- colnames(chain1_bivariate$X)

bivariate_results <- round(t(rbind(apply(beta.samples.matrix_bivariate, 2, mean), 
                                   apply(beta.samples.matrix_bivariate, 2, quantile, c(0.025, 0.975)))), 5) %>% 
  as.data.frame() %>% 
  rownames_to_column() %>% 
  rename(term = rowname,
         mean = V1,
         ci.low = `2.5%`,
         ci.high = `97.5%`) %>% 
  mutate(mean = round(exp(mean), 3),
         ci.low = round(exp(ci.low), 3),
         ci.high = round(exp(ci.high), 3))

set.seed(1)
chain1_multivariate <- CARBayes::S.CARleroux(
  formula = temp_double_lasso_formula_psychiatrist_accessibility,
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

set.seed(2)
chain2_multivariate <- CARBayes::S.CARleroux(
  formula = temp_double_lasso_formula_psychiatrist_accessibility,
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

set.seed(3)
chain3_multivariate <- CARBayes::S.CARleroux(
  formula = temp_double_lasso_formula_psychiatrist_accessibility,
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

set.seed(4)
chain4_multivariate <- CARBayes::S.CARleroux(
  formula = temp_double_lasso_formula_psychiatrist_accessibility,
  data = access_df_for_spatial_regression %>% 
    mutate(suicide_rate = round(suicide_rate * total_pop)),
  family="binomial", 
  W = wm2,
  trials = access_df_for_spatial_regression$total_pop,
  burnin= 100000 / CARBayes_ratio, n.sample= 350000 / CARBayes_ratio, thin= 100 / CARBayes_ratio)

beta.samples.matrix_multivariate <- rbind(chain1_multivariate$samples$beta, 
                                          chain2_multivariate$samples$beta, 
                                          chain3_multivariate$samples$beta,
                                          chain4_multivariate$samples$beta)
colnames(beta.samples.matrix_multivariate) <- colnames(chain1_multivariate$X)

multivariate_results <- round(t(rbind(apply(beta.samples.matrix_multivariate, 2, mean), 
                                      apply(beta.samples.matrix_multivariate, 2, quantile, c(0.025, 0.975)))), 5) %>% 
  as.data.frame() %>% 
  rownames_to_column() %>% 
  rename(term = rowname,
         mean = V1,
         ci.low = `2.5%`,
         ci.high = `97.5%`) %>% 
  mutate(mean = round(exp(mean), 3),
         ci.low = round(exp(ci.low), 3),
         ci.high = round(exp(ci.high), 3))

# data for forest plot
df_blobbogram2 <- bind_rows(df_blobbogram2,
                            multivariate_results %>% 
                              filter(term == "psychiatrist_general_tract_access") %>% 
                              select(term,
                                     b = mean,
                                     conf.low = ci.low,
                                     conf.high = ci.high) %>% 
                              mutate(type = "CAR",
                                     term = "Psychiatirst accessibility"))

# psychotherapist double lasso
temp_df <- access_df[!is.na(access_df$suicide_rate), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_community_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_institutional_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_family_unity), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_collective_efficacy), ]

temp_df <- temp_df %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) %>% 
  pivot_longer(dead:alive, names_to = "dead_x") %>% 
  rename(dead = dead_x) %>% 
  mutate(dead = ifelse(dead == "dead", 1, 0)) %>% 
  filter(value > 0) 

temp_df_therapist <- temp_df %>% 
  filter(!is.na(therapist_general_tract_access))

confounder_variables <- temp_df_therapist[, c(
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- pull(temp_df_therapist, dead)
outcome <- ifelse(outcome == 1, TRUE, FALSE) 
weights <- pull(temp_df_therapist, value)
treatment <- temp_df_therapist$therapist_general_tract_access
x <- bind_cols(confounder_variables, outcome = outcome, weights = weights, treatment = treatment)
x <- uncount(x, weights = weights) 
outcome <- pull(x, outcome)
treatment <- pull(x, treatment)
x.matrix <- as.matrix(x %>% select(-outcome, -treatment))
rm(x)

lasso <- hdm::rlassologit(x = x.matrix,
                          y = outcome)

lasso_keep_1 <- as.data.frame(lasso$beta) %>%
  rownames_to_column() %>%
  janitor::clean_names() %>% 
  mutate(lasso_beta = lasso_beta != 0) %>% 
  rename(lasso_keep = lasso_beta)

temp_df <- access_df[!is.na(access_df$suicide_rate), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_community_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_institutional_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_family_unity), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_collective_efficacy), ]

temp_df_therapist <- temp_df %>% 
  filter(!is.na(therapist_general_tract_access))

confounder_variables <- temp_df_therapist[, c(
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
  mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

treatment <- temp_df_therapist$therapist_general_tract_access

hdm.accessibility.lasso <- hdm::rlasso(x = confounder_variables, 
                                       y = treatment)

lasso_keep_2 <- as.data.frame(hdm.accessibility.lasso$coefficients) %>%
  rownames_to_column() %>% 
  rename(lasso_keep = `hdm.accessibility.lasso$coefficients`) %>% 
  mutate(lasso_keep = lasso_keep != 0) %>% 
  filter(rowname != "(Intercept)")

temp_double_lasso_formula_therapist_accessibility <- as.formula(paste0("suicide_rate ~ therapist_general_tract_access + ", bind_rows(lasso_keep_1, lasso_keep_2) %>% filter(lasso_keep) %>% distinct %>% summarize(x = paste0(rowname, collapse = " + "))))

temp_double_lasso_regression <- glm(temp_double_lasso_formula_therapist_accessibility,
                                    weights = total_pop,
                                    family = "binomial",
                                    data = access_df_std) 

# accessibility gaps
temp_deciles_accessibility <- access_df %>% 
  summarize(therapist_general_tract_access = 
              Hmisc::wtd.quantile(therapist_general_tract_access, probs = c(.1, .9), weights = total_pop, na.rm = TRUE)) %>% 
  pull %>% 
  as.numeric()

# data for forest plot
df_blobbogram2 <- bind_rows(df_blobbogram2,
                            broom::tidy(temp_double_lasso_regression, conf.int = TRUE) %>% 
                              filter(term == "therapist_general_tract_access") %>% 
                              mutate(across(matches("estimate|conf"), exp)) %>% 
                              select(term,
                                     b = estimate,
                                     se = std.error,
                                     p = p.value,
                                     conf.low, conf.high) %>% 
                              mutate(type = "double_lasso",
                                     term = "Psychotherapist accessibility"))

# spatial autocorrelation
county_shp <- sf::st_read(here("data", "cb_2018_us_county_5m", "cb_2018_us_county_5m.shp"))

df_x_therapist_access_for_spatial_regression <- 
  access_df[complete.cases(access_df %>% 
                             select(county_code, therapist_general_tract_access, 
                                    suicide_rate)), ]

variables_to_keep <- bind_rows(lasso_keep_1, lasso_keep_2) %>% 
  filter(lasso_keep) %>% 
  distinct %>% 
  pull(rowname)

df_x_therapist_access_for_spatial_regression <- df_x_therapist_access_for_spatial_regression[
  df_x_therapist_access_for_spatial_regression %>% 
    select(matches(variables_to_keep)) %>% 
    complete.cases(), ]

good_counties <- df_x_therapist_access_for_spatial_regression %>%
  pull(county_code) %>%
  unique

county_shp <- county_shp %>%
  filter(GEOID %in% good_counties)

df_x_therapist_access_for_spatial_regression <- df_x_therapist_access_for_spatial_regression %>%
  filter(county_code %in% (county_shp %>% pull(GEOID) %>% unique))

list.queen <- poly2nb(county_shp, queen=TRUE)
rwm <- nb2listw(list.queen, style="B", zero.policy=TRUE)

add_nb <- function(x){
  
  queen_nb <- poly2nb(x, queen = TRUE)
  
  count = card(queen_nb)
  if(!any(count==0)){
    return(queen_nb)
  }
  
  nnbs = knearneigh(st_coordinates(st_centroid(x)))$nn
  no_edges_from = which(count==0)
  for(i in no_edges_from){
    queen_nb[[i]] = nnbs[i]
  }
  return(queen_nb)
}

new_queen_nb <- add_nb(county_shp)
W <- nb2listw(new_queen_nb, style="B", zero.policy=TRUE)
wm <- nb2mat(new_queen_nb, style = "B", zero.policy = TRUE)
rwm <- mat2listw(wm, style = "B")

morans_function <- function(glm_formula, df){
  
  glm.model <- fixest::feglm(glm_formula,
                             cluster = ~state,
                             weights = ~total_pop,
                             data = df)
  
  moran.lm <- moran.test(residuals(glm.model), rwm, alternative="two.sided", zero.policy = TRUE)
  moran.mc.object <- moran.mc(x=residuals(glm.model), listw=rwm, nsim=10000)
  
  return(list(moran.lm, moran.mc.object))
  
}

morans_therapist_post_double_lasso <- morans_function(temp_double_lasso_formula_therapist_accessibility, df_x_therapist_access_for_spatial_regression)
morans_therapist_accessibility_bivariate <- morans_function(as.formula("suicide_rate ~ psychiatrist_general_tract_access"), df_x_therapist_access_for_spatial_regression)

# forest plot
df_blobbogram2_for_plotting <- df_blobbogram2 %>% 
  mutate(term = paste0(term, "$", type)) %>% 
  select(-se) %>% 
  mutate(p = map(p, adjust_p, FALSE) %>% unlist) %>% 
  mutate(significance = ifelse(p == "< .001", 0, as.numeric(p)),
         significance = case_when(significance == 0 ~ "",
                                  significance < .01 ~ "††",
                                  significance < .05 ~ "†",
                                  significance >= .05 ~ "‡")) %>% 
  mutate(term = ifelse(str_detect(tolower(term), "psychia"), "Psychiatrist\naccessbility", "Psychotherapist\naccessbility")) %>% 
  mutate(type = case_when(type == "bivariate" ~ "Bivariate",
                          type == "multivariate" ~ "Multivariate",
                          type == "double_lasso" ~ "Double lasso",
                          type == "CAR" ~ "CAR")) %>% 
  mutate(fake_type = ifelse(type == "Bivariate", 1, NA),
         fake_type = ifelse(type == "Multivariate", 2, fake_type),
         fake_type = ifelse(type == "Double lasso", 3, fake_type),
         fake_type = ifelse(type == "CAR", 4, fake_type)) %>% 
  mutate(fake_type = factor(fake_type)) %>% 
  mutate(type = factor(type, levels = c("Bivariate", "Multivariate", "Double lasso", "CAR")),
         term = factor(term, levels = c("Psychiatrist\naccessbility",  "Psychotherapist\naccessbility"))) %>%
  filter(term != "Psychotherapist\naccessbility" | type != "CAR") %>% 
  arrange(type) %>% 
  mutate(fakex = ifelse(str_detect(term, "Psychiatrist"), 1, 2)) 

df_blobbogram2_for_plotting %>% 
  ggplot(aes(x = fakex, y = b, ymin = conf.low, ymax = conf.high, color = fake_type, label = significance)) +
  geom_point(data = df_blobbogram2_for_plotting %>% filter(str_detect(term, "therapist")), 
             aes(x = fakex, y = b, color = fake_type), 
             size = 2.5, position = position_dodge(width = -0.65)) +
  geom_point(data = df_blobbogram2_for_plotting %>% filter(str_detect(term, "Psychi")), 
             aes(x = fakex, y = b, color = fake_type), 
             size = 2.5, position = position_dodge(width = -0.85)) +
  geom_errorbar(data = df_blobbogram2_for_plotting %>% filter(str_detect(term, "therapist")), 
                aes(x = fakex, ymin = conf.low, ymax = conf.high, color = fake_type),
                width=.25, linetype = 1, position = position_dodge(width = -0.65)) +
  geom_errorbar(data = df_blobbogram2_for_plotting %>% filter(str_detect(term, "Psychi")), 
                aes(x = fakex, ymin = conf.low, ymax = conf.high, color = fake_type),
                width=.25, linetype = 1, position = position_dodge(width = -0.85)) +
  geom_text(data = df_blobbogram2_for_plotting %>% filter(str_detect(term, "therapist")), 
            aes(x = fakex, y = conf.low - .004, group = fake_type), size = 2, color = "black", 
            position = position_dodge(width = -0.65)) +
  geom_text(data = df_blobbogram2_for_plotting %>% filter(str_detect(term, "Psychi")),
            aes(x = fakex, y = conf.low - .004, group = fake_type), size = 2, color = "black", 
            position = position_dodge(width = -0.85)) +
  labs(x=NULL, y = "Suicide Risk") +
  geom_hline(yintercept=1, color='black', linetype='dashed', alpha=.35) + 
  theme_classic() +
  scale_colour_brewer(palette = "Set1", labels = c("Bivariate", "Multivariate", "Double lasso", "CAR")) +
  coord_flip(ylim = c(NA, NA)) +
  scale_x_reverse(breaks = c(1, 2), labels = c("Psychiatrist\naccessbility",  "Psychotherapist\naccessbility")) +
  theme(
    legend.position = "bottom",
    legend.title = element_blank(),
    legend.box.margin=margin(-10,-10,-10,-10),
    legend.margin=margin(0,0,0,0),
    legend.text = element_text(family = "IBM Plex Sans Light", size = 7.25 , margin = margin(r = 1, unit = 'cm')),
    plot.title = element_text(family = "IBM Plex Sans Light", size = 10),
    plot.caption = element_text(family = "IBM Plex Sans Light"),
    axis.title.x = element_text(family = "IBM Plex Sans Light", vjust = -.25, size = 9),
    axis.title.y = element_text(family = "IBM Plex Sans Light"),
    axis.text.x = element_text(family = "IBM Plex Sans Light"),
    axis.text.y = element_text(family = "IBM Plex Sans Light"))

# homicide
temp_df <- access_df[!is.na(access_df$homicide_rate), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_community_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_institutional_health), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_family_unity), ]
temp_df <- temp_df[!is.na(temp_df$soc_capital_collective_efficacy), ]

temp_df <- temp_df %>% 
  mutate(dead = round(total_pop * (homicide_rate)),
         alive = total_pop - round(total_pop * (homicide_rate)))

temp_df_psychiatrist <- temp_df %>% 
  filter(!is.na(psychiatrist_general_tract_access),
         !is.na(psychiatrist_availaibility))

temp_df_therapist <- temp_df %>% 
  filter(!is.na(therapist_general_tract_access),
         !is.na(therapist_availability))

temp_df_all_providers <- temp_df %>% 
  filter(!is.na(psychiatrist_general_tract_access),
         !is.na(psychiatrist_availaibility),
         !is.na(therapist_general_tract_access),
         !is.na(therapist_availability))

confounder_variables <- temp_df_psychiatrist[, c(
  "psychiatrist_general_tract_access",
  "psychiatrist_availaibility",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- matrix(c(temp_df_psychiatrist$alive, temp_df_psychiatrist$dead), ncol = 2) 
weights <- temp_df_psychiatrist$total_pop

cvfit <- cv.glmnet(x = confounder_variables, 
                   y = outcome, 
                   weights = weights,
                   family = c("binomial"), 
                   alpha = 1,
                   type.measure = "mse",
                   nfolds = 10)

lasso_psychiatrist <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_psychiatrist <- bind_rows(
  tibble(
    rowname = lasso_psychiatrist$beta@Dimnames[[1]][as.list(lasso_psychiatrist$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_psychiatrist$beta@Dimnames[[1]][as.list(lasso_psychiatrist$beta) == 0],
    lasso_keep = FALSE)
)
 
rm(cvfit, weights, outcome, confounder_variables, temp_df_psychiatrist)

confounder_variables <- temp_df_therapist[, c(
  "therapist_general_tract_access",
  "therapist_availability",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- matrix(c(temp_df_therapist$alive, temp_df_therapist$dead), ncol = 2) 
weights <- temp_df_therapist$total_pop

cvfit <- cv.glmnet(x = confounder_variables, 
                   y = outcome, 
                   weights = weights,
                   family = c("binomial"), 
                   alpha = 1,
                   type.measure = "mse",
                   nfolds = 10)

lasso_therapist <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_therapist <- bind_rows(
  tibble(
    rowname = lasso_therapist$beta@Dimnames[[1]][as.list(lasso_therapist$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_therapist$beta@Dimnames[[1]][as.list(lasso_therapist$beta) == 0],
    lasso_keep = FALSE)
)

rm(cvfit, weights, outcome, confounder_variables, temp_df_therapist)

confounder_variables <- temp_df_all_providers[, c(
  "psychiatrist_general_tract_access",
  "therapist_general_tract_access",
  "psychiatrist_availaibility",
  "therapist_availability",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- matrix(c(temp_df_all_providers$alive, temp_df_all_providers$dead), ncol = 2) 
weights <- temp_df_all_providers$total_pop

cvfit <- cv.glmnet(x = confounder_variables, 
                   y = outcome, 
                   weights = weights,
                   family = c("binomial"), 
                   alpha = 1,
                   type.measure = "mse",
                   nfolds = 10)

lasso_all_providers <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_all_providers <- bind_rows(
  tibble(
    rowname = lasso_all_providers$beta@Dimnames[[1]][as.list(lasso_all_providers$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_all_providers$beta@Dimnames[[1]][as.list(lasso_all_providers$beta) == 0],
    lasso_keep = FALSE)
)

# table
homicide_lassos_gt_df <-bind_rows(
  data.frame(
    term = lasso_psychiatrist$beta@Dimnames[[1]],
    b = lasso_psychiatrist$beta %>% as.numeric(),
    model = "psychiatrists"), 
  data.frame(
    term = lasso_therapist$beta@Dimnames[[1]],
    b = lasso_therapist$beta %>% as.numeric(),
    model = "therapists"),
  data.frame(
    term = lasso_all_providers$beta@Dimnames[[1]],
    b = lasso_all_providers$beta %>% as.numeric(),
    model = "all_providers")
) %>% 
  pivot_wider(names_from = model, values_from = b) %>%
  mutate(across(is.numeric, round, 3))

homicide_lassos_gt_df %>% 
  fix_terms() %>% 
  factorize_terms() %>% 
  gt(rowname_col = "term") %>% 
  tab_header(title = md(paste0("**Table SX. Logistic Lasso Regressions of the Correlates of County-level Homicide**"))) %>% 
  cols_label(
    psychiatrists = "Psychiatrists",
    therapists = "Psychotherapists",
    all_providers = "All providers"
  ) %>% 
    tab_options(table.font.siz = pct(90)) %>% 
    fmt_missing(columns = everything(), missing_text = "...") %>%
  tab_footnote(
    footnote = "Covariates standardized.",
    locations = cells_title(groups = "title")) %>% 
  tab_footnote(
    footnote = paste0("N=", lasso_psychiatrist$nobs %>% prettify),
    locations = cells_column_labels(columns = psychiatrists)) %>% 
  tab_footnote(
    footnote = paste0("N=", lasso_therapist$nobs %>% prettify),
    locations = cells_column_labels(columns = therapists)) %>% 
  tab_footnote(
    footnote = paste0("N=", lasso_all_providers$nobs %>% prettify),
    locations = cells_column_labels(columns = all_providers))

rm(lasso_psychiatrist, lasso_therapist, lasso_all_providers, lasso_all_providers, cvfit, weights, outcome, confounder_variables, temp_df_all_providers)

# psychiatrist accessibility inequality
temp_df_psychiatrist_gini <- access_df[!is.na(access_df$suicide_rate), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_community_health), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_institutional_health), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_family_unity), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_collective_efficacy), ]

temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini %>% 
  filter(!is.na(county_gini_psychiatrist)) %>% 
  filter(!is.na(psychiatrist_general_tract_access))

temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) %>% 
  pivot_longer(dead:alive, names_to = "dead_x") %>% 
  rename(dead = dead_x) %>% 
  mutate(dead = ifelse(dead == "dead", 1, 0)) %>% 
  filter(value > 0) 

confounder_variables <- temp_df_psychiatrist_gini[, c(
  "psychiatrist_general_tract_access", 
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- pull(temp_df_psychiatrist_gini, dead)
outcome <- ifelse(outcome == 1, TRUE, FALSE) 
weights <- pull(temp_df_psychiatrist_gini, value)
treatment <- pull(temp_df_psychiatrist_gini, county_gini_psychiatrist)
x <- bind_cols(confounder_variables, outcome = outcome, weights = weights, treatment = treatment)
x <- uncount(x, weights = weights) 
outcome <- pull(x, outcome)
treatment <- pull(x, treatment)
x.matrix <- as.matrix(x %>% select(-outcome, -treatment))
rm(x)

lasso <- hdm::rlassologit(x = x.matrix,
                          y = outcome)

lasso_keep_1 <- as.data.frame(lasso$beta) %>% 
  rownames_to_column() %>% 
  rename(lasso_keep = 'lasso$beta') %>% 
  mutate(lasso_keep = lasso_keep != 0)
  
temp_df_psychiatrist_gini <- access_df[!is.na(access_df$suicide_rate), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_community_health), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_institutional_health), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_family_unity), ]
temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini[!is.na(temp_df_psychiatrist_gini$soc_capital_collective_efficacy), ]

temp_df_psychiatrist_gini <- temp_df_psychiatrist_gini %>% 
  filter(!is.na(county_gini_psychiatrist)) %>% 
  filter(!is.na(psychiatrist_general_tract_access))

confounder_variables <- temp_df_psychiatrist_gini[, c(
  "psychiatrist_general_tract_access", 
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

treatment <- pull(temp_df_psychiatrist_gini, county_gini_psychiatrist)

hdm.accessibility.lasso <- hdm::rlasso(x = confounder_variables, 
                                       y = treatment)

lasso_keep_2 <- as.data.frame(hdm.accessibility.lasso$coefficients) %>%
  rownames_to_column() %>% 
  rename(lasso_keep = `hdm.accessibility.lasso$coefficients`) %>% 
  mutate(lasso_keep = lasso_keep != 0) %>% 
  filter(rowname != "(Intercept)")

temp_double_lasso_formula <- as.formula(paste0("suicide_rate ~ county_gini_psychiatrist + ", bind_rows(lasso_keep_1, lasso_keep_2) %>% filter(lasso_keep) %>% distinct %>%  summarize(x = paste0(rowname, collapse = " + "))))

temp_double_lasso_regression <- fixest::feglm(temp_double_lasso_formula,
                                              weights = ~total_pop,
                                              family = "binomial",
                                              data = temp_df_psychiatrist_gini)

temp_tidy_double_lasso_psychiatrist_inequality <- broom::tidy(temp_double_lasso_regression, conf.int = TRUE) %>% 
  mutate(estimate = exp(estimate),
         conf.low = exp(conf.low),
         conf.high = exp(conf.high)) %>% 
  filter(term != "(Intercept)")

# accessibility inequality gaps
temp_deciles <- access_df %>% 
  summarize(psychiatrist_gini_top_bottom_deciles = 
              Hmisc::wtd.quantile(county_gini_psychiatrist, probs = c(.25, .75), weights = total_pop, na.rm = TRUE),
            therapist_gini_top_bottom_deciles = 
              Hmisc::wtd.quantile(county_gini_therapist, probs = c(.25, .75), weights = total_pop, na.rm = TRUE))

# glm
temp_double_lasso_formula <- as.formula(paste0("suicide_rate ~ county_gini_psychiatrist_std + ", bind_rows(lasso_keep_1, lasso_keep_2) %>% filter(lasso_keep) %>% distinct %>% summarize(x = paste0(rowname, collapse = " + "))))

temp_double_lasso_regression <- fixest::feglm(temp_double_lasso_formula,
                                              weights = ~total_pop,
                                              cluser = ~state,
                                              family = "binomial",
                                              data = temp_df_psychiatrist_gini %>% 
                                                mutate(county_gini_psychiatrist_std = scale(county_gini_psychiatrist)))

temp_tidy_double_lasso_std <- broom::tidy(temp_double_lasso_regression, conf.int = TRUE) %>% 
  mutate(estimate = exp(estimate),
         conf.low = exp(conf.low),
         conf.high = exp(conf.high)) %>% 
  filter(term != "(Intercept)")

# psychotherapist accessibility inequality 
temp_df_therapist_gini <- access_df[!is.na(access_df$suicide_rate), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_community_health), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_institutional_health), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_family_unity), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_collective_efficacy), ]

temp_df_therapist_gini <- temp_df_therapist_gini %>% 
  filter(!is.na(county_gini_therapist)) %>% 
  filter(!is.na(therapist_general_tract_access))

temp_df_therapist_gini <- temp_df_therapist_gini %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) %>% 
  pivot_longer(dead:alive, names_to = "dead_x") %>% 
  rename(dead = dead_x) %>% 
  mutate(dead = ifelse(dead == "dead", 1, 0)) %>% 
  filter(value > 0) 

confounder_variables <- temp_df_therapist_gini[, c(
  "therapist_general_tract_access", 
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

outcome <- pull(temp_df_therapist_gini, dead)
outcome <- ifelse(outcome == 1, TRUE, FALSE) 
weights <- pull(temp_df_therapist_gini, value)
treatment <- pull(temp_df_therapist_gini, county_gini_therapist)
x <- bind_cols(confounder_variables, outcome = outcome, weights = weights, treatment = treatment)
x <- uncount(x, weights = weights) 
outcome <- pull(x, outcome)
treatment <- pull(x, treatment)
x.matrix <- as.matrix(x %>% select(-outcome, -treatment))
rm(x)

lasso <- hdm::rlassologit(x = x.matrix,
                          y = outcome)

lasso_keep_1 <- as.data.frame(lasso$beta) %>% 
  rownames_to_column() %>% 
  rename(lasso_keep = 'lasso$beta') %>% 
  mutate(lasso_keep = lasso_keep != 0) 

temp_df_therapist_gini <- access_df[!is.na(access_df$suicide_rate), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_community_health), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_institutional_health), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_family_unity), ]
temp_df_therapist_gini <- temp_df_therapist_gini[!is.na(temp_df_therapist_gini$soc_capital_collective_efficacy), ]

temp_df_therapist_gini <- temp_df_therapist_gini %>% 
  filter(!is.na(county_gini_therapist)) %>% 
  filter(!is.na(therapist_general_tract_access))

confounder_variables <- temp_df_therapist_gini[, c(
  "therapist_general_tract_access",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)] %>% 
    mutate_all(~(scale(.) %>% 
                 as.vector)) %>% 
  as.matrix()

treatment <- pull(temp_df_therapist_gini, county_gini_therapist)

hdm.accessibility.lasso <- hdm::rlasso(x = confounder_variables, 
                                       y = treatment)

lasso_keep_2 <- as.data.frame(hdm.accessibility.lasso$coefficients) %>%
  rownames_to_column() %>% 
  rename(lasso_keep = `hdm.accessibility.lasso$coefficients`) %>% 
  mutate(lasso_keep = lasso_keep != 0) %>% 
  filter(rowname != "(Intercept)")

temp_double_lasso_formula <- as.formula(paste0("suicide_rate ~ county_gini_therapist + ", bind_rows(lasso_keep_1, lasso_keep_2) %>% filter(lasso_keep) %>% distinct %>% summarize(x = paste0(rowname, collapse = " + "))))

temp_double_lasso_regression <- fixest::feglm(temp_double_lasso_formula,
                                              weights = ~total_pop,
                                              family = "binomial",
                                              data = temp_df_psychiatrist_gini)

temp_tidy_double_lasso <- broom::tidy(temp_double_lasso_regression, conf.int = TRUE) %>% 
  mutate(estimate = exp(estimate),
         conf.low = exp(conf.low),
         conf.high = exp(conf.high)) %>% 
  filter(term != "(Intercept)")

# accessibility inequality gaps
temp_deciles <- access_df %>% 
  summarize(therapist_gini_top_bottom_deciles = 
              Hmisc::wtd.quantile(county_gini_therapist, probs = c(.25, .75), weights = total_pop, na.rm = TRUE))

# glm
temp_double_lasso_formula <- as.formula(paste0("suicide_rate ~ county_gini_therapist_std + ", bind_rows(lasso_keep_1, lasso_keep_2) %>% filter(lasso_keep) %>% distinct %>% summarize(x = paste0(rowname, collapse = " + "))))

temp_double_lasso_regression <- fixest::feglm(temp_double_lasso_formula,
                                              weights = ~total_pop,
                                              cluser = ~state,
                                              family = "binomial",
                                              data = temp_df_psychiatrist_gini %>% 
                                                mutate(county_gini_therapist_std = scale(county_gini_therapist)))

temp_tidy_double_lasso_std <- broom::tidy(temp_double_lasso_regression, conf.int = TRUE) %>% 
  mutate(estimate = exp(estimate),
         conf.low = exp(conf.low),
         conf.high = exp(conf.high)) %>% 
  filter(term != "(Intercept)")

# income inequality
temp_df_psychiatrist_gini_income <- access_df[!is.na(access_df$suicide_rate), ]

temp_df_psychiatrist_gini_income <- temp_df_psychiatrist_gini_income %>% 
  filter(!is.na(county_gini_psychiatrist),
         !is.na(psychiatrist_general_tract_access),
         !is.na(acs_county_level_gini)) %>% 
  mutate(acs_county_level_gini = as.numeric(acs_county_level_gini))

temp_df_psychiatrist_gini_income <- temp_df_psychiatrist_gini_income %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) 

confounder_variables <- as.matrix(temp_df_psychiatrist_gini_income[, c(
  "psychiatrist_general_tract_access",
  "acs_county_level_gini",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)])

confounder_variables <- as.matrix(as.data.frame(confounder_variables) %>% 
                                    mutate_all(~(scale(.) %>% 
                                                   as.vector)))

outcome <- matrix(c(temp_df_psychiatrist_gini_income$alive, temp_df_psychiatrist_gini_income$dead), ncol = 2)   
weights <- temp_df_psychiatrist_gini_income$total_pop

cvfit <- glmnet::cv.glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  alpha = 1,
  type.measure = "mse",
  nfolds = 10)

lasso_outcome <- glmnet::glmnet(
  x = confounder_variables,  
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_outcome <- bind_rows(
  tibble(
    rowname = lasso_outcome$beta@Dimnames[[1]][as.list(lasso_outcome$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_outcome$beta@Dimnames[[1]][as.list(lasso_outcome$beta) == 0],
    lasso_keep = FALSE)
)

# table
income_inequality_lassos_gt_df <- data.frame(
  term = lasso_outcome$beta@Dimnames[[1]],
  b = lasso_outcome$beta %>% as.numeric(),
  model = "income_ineuquality_alone") %>% 
  pivot_wider(names_from = model, values_from = b) %>% 
  mutate(across(is.numeric, round, 3))

income_ineuquality_alone_n = lasso_outcome$nobs

# accessibility and income inequality
temp_df_psychiatrist_gini_income <- access_df[!is.na(access_df$suicide_rate), ]

temp_df_psychiatrist_gini_income <- temp_df_psychiatrist_gini_income %>% 
  filter(!is.na(county_gini_psychiatrist)) %>% 
  mutate(acs_county_level_gini = as.numeric(acs_county_level_gini))

temp_df_psychiatrist_gini_income <- temp_df_psychiatrist_gini_income %>% 
  mutate(dead = round(total_pop * suicide_rate),
         alive = total_pop - round(total_pop * suicide_rate)) 

confounder_variables <- as.matrix(temp_df_psychiatrist_gini_income[, c(
  "psychiatrist_general_tract_access",
  "county_gini_psychiatrist",
  "acs_county_level_gini",
  "rurality_1_to_10", 
  "pop_density_1k_ppl_per_sq_mile", 
  "separated_or_divorced_in_10_pct", 
  "pct_born_in_the_usa_in_10_pct", 
  "insurance_rate_in_10_pct", 
  "unemployment_rate_in_10_pct", 
  "median_age", 
  "males_in_10_pct", 
  "poverty_in_10_pct", 
  "ADI_NATRANK", 
  "ba_degree_over_25_prop_in_10_pct", 
  "med_household_income_in_10K", 
  "pop_white_non_hispanic_in_10_pct",
  "pop_black_non_hispanic_in_10_pct",
  "pop_asian_non_hispanic_in_10_pct",
  "pop_hispanic_all_races_in_10_pct",
  "soc_capital_community_health",
  "soc_capital_collective_efficacy",
  "soc_capital_family_unity",
  "soc_capital_institutional_health",
  "liquor_and_drinking_ratio",
  "gun_store_ratio"
)])

confounder_variables <- as.matrix(as.data.frame(confounder_variables) %>% 
                                    mutate_all(~(scale(.) %>% 
                                                   as.vector)))

outcome <- matrix(c(temp_df_psychiatrist_gini_income$alive, temp_df_psychiatrist_gini_income$dead), ncol = 2)   
weights <- temp_df_psychiatrist_gini_income$total_pop

cvfit <- glmnet::cv.glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  alpha = 1,
  type.measure = "mse",
  nfolds = 10)

lasso_outcome <- glmnet::glmnet(
  x = confounder_variables, 
  y = outcome, 
  weights = weights,
  family = c("binomial"), 
  lambda = cvfit$lambda.1se,
  alpha = 1)

lasso_keep_outcome <- bind_rows(
  tibble(
    rowname = lasso_outcome$beta@Dimnames[[1]][as.list(lasso_outcome$beta) != 0],
    lasso_keep = TRUE),
  tibble(
    rowname = lasso_outcome$beta@Dimnames[[1]][as.list(lasso_outcome$beta) == 0],
    lasso_keep = FALSE)
)

income_inequality_lassos_gt_df <-
  full_join(income_inequality_lassos_gt_df,
            data.frame(
              term = lasso_outcome$beta@Dimnames[[1]],
              b = lasso_outcome$beta %>% as.numeric(),
              model = "income_ineuquality_with_accessibility_inequality") %>% 
              pivot_wider(names_from = model, values_from = b) %>% 
              mutate(across(is.numeric, round, 3)))

income_ineuquality_with_accessibility_inequality_n <- lasso_outcome$nobs

income_inequality_lassos_gt_df %>% 
  fix_terms() %>% 
  factorize_terms() %>% 
  gt(rowname_col = "term") %>% 
  tab_header(title = md(paste0("**Table SX. Logistic Lasso Regressions of the Correlates of County-level Suicide Risk, Including Income Inequality**"))) %>% 
  cols_label(
    income_ineuquality_alone = "Model 1", 
    income_ineuquality_with_accessibility_inequality = "Model 2"
  ) %>% 
  tab_options(table.font.siz = pct(90)) %>% 
  fmt_missing(columns = everything(), missing_text = "...") %>%
  tab_footnote(
    footnote = "Covariates standardized. Coefficients presented as log odds.",
    locations = cells_title(groups = "title")) %>% 
  tab_footnote(
    footnote = paste0("N=", income_ineuquality_alone_n %>% prettify),
    locations = cells_column_labels(columns = income_ineuquality_alone)) %>% 
  tab_footnote(
    footnote = paste0("N=", income_ineuquality_with_accessibility_inequality_n %>% prettify),
    locations = cells_column_labels(columns = income_ineuquality_with_accessibility_inequality)) 

rm(income_ineuquality_alone_n, income_ineuquality_with_accessibility_inequality_n)