providers_psychiatrists_alone_unscaled <- providers_psychiatrists_alone %>% 
  select(GEOID,
         psychiatrist_general_tract_access_unscaled = psychiatrist_general_tract_access, 
         therapist_general_tract_access_unscaled = therapist_general_tract_access)

providers_psychiatrists_alone_scaled <- providers_psychiatrists_alone %>% 
  mutate(psychiatrist_general_tract_access = corpcor::wt.scale(psychiatrist_general_tract_access, total_pop)) %>% 
  left_join(providers_psychiatrists_alone_unscaled)

providers_filtering_states_scaled <- providers_filtering_states %>% 
  filter(!is.na(therapist_general_tract_access)) %>% 
  mutate(psychiatrist_general_tract_access = corpcor::wt.scale(psychiatrist_general_tract_access, total_pop),
         therapist_general_tract_access = corpcor::wt.scale(therapist_general_tract_access, total_pop)) %>% 
  left_join(providers_psychiatrists_alone_unscaled %>% select(GEOID, therapist_general_tract_access_unscaled))

rm(providers_psychiatrists_alone_unscaled)

# divides all columns ending with "in_pct" by 10, and changes names
change_1_pct_to_10 <- function(df){
  df <- df %>% 
    mutate(across(ends_with("in_pct"), function(x) as.numeric(x)/10)) 
  
  colnames(df) <- str_replace(colnames(df), "in_pct", "in_10_pct")
  
  return(df)
}

providers_filtering_states <- change_1_pct_to_10(providers_filtering_states)
providers_filtering_states_scaled <- change_1_pct_to_10(providers_filtering_states_scaled)
providers_psychiatrists_alone <- change_1_pct_to_10(providers_psychiatrists_alone)
providers_psychiatrists_alone_scaled <- change_1_pct_to_10(providers_psychiatrists_alone_scaled)

rm(change_1_pct_to_10)

# psychiatrist accessibility inequality per county
county_list <- providers_psychiatrists_alone %>% 
  filter(!is.na(county_code)) %>% 
  pull(county_code) %>% 
  unique

county_gini_df_psychiatrist <- tibble()

for(county in county_list){
  
  temp_df <- providers_psychiatrists_alone %>% 
    filter(county_code == county)
  
  gini <- DescTools::Gini(temp_df$psychiatrist_general_tract_access, na.rm = TRUE)

  county_gini_df_psychiatrist <- bind_rows(county_gini_df_psychiatrist, 
                                           tibble(county_code = county,
                                                  county_gini_psychiatrist = gini
                                           ))
}

providers_psychiatrists_alone <- left_join(providers_psychiatrists_alone, county_gini_df_psychiatrist)
providers_psychiatrists_alone_scaled <- left_join(providers_psychiatrists_alone_scaled, county_gini_df_psychiatrist)
rm(temp_df, gini, county, county_list, county_gini_df_psychiatrist)

# therapist accessibility inequality per county
county_list <- providers_filtering_states %>% 
  filter(!is.na(county_code)) %>% 
  pull(county_code) %>% 
  unique

county_gini_df_therapist <- tibble()

for(county in county_list){
  
  temp_df <- providers_psychiatrists_alone %>% 
    filter(county_code == county) %>% 
    filter(!is.na(therapist_general_tract_access))
  
  gini <- DescTools::Gini(temp_df$therapist_general_tract_access, na.rm = TRUE)

  county_gini_df_therapist <- bind_rows(county_gini_df_therapist, 
                                        tibble(county_code = county,
                                               county_gini_therapist = gini
                                               ))
}

providers_filtering_states <- left_join(providers_filtering_states, county_gini_df_therapist)
providers_filtering_states_scaled <- left_join(providers_filtering_states_scaled, county_gini_df_therapist)
rm(temp_df, gini, county, county_list, county_gini_df_therapist)

# loading suicide rates from CDC [# Intentional self-harm (suicide) (*U03,X60-X84,Y87.0)]
clean_csv <- function(df){
  
  df %>% 
    janitor::clean_names() %>% 
    filter(!is.na(deaths)) %>% 
    select(-notes) %>% 
    filter(county != "Total")
  
}

suicide_data <- read_tsv(here("data", "Suicide deaths 2018-2020.txt")) %>%
  clean_csv() %>%
  select(county_code, population, deaths) %>%
  mutate(suicide_rate = deaths / (population / 100000)) %>%
  select(county_code, suicide_rate)

providers_filtering_states <- left_join(providers_filtering_states, suicide_data)
providers_filtering_states_scaled <- left_join(providers_filtering_states_scaled, suicide_data)
providers_psychiatrists_alone <- left_join(providers_psychiatrists_alone, suicide_data)
providers_psychiatrists_alone_scaled <- left_join(providers_psychiatrists_alone_scaled, suicide_data)

# loading homicide rates from CDC [# Assault (homicide) (*U01-*U02,X85-Y09,Y87.1)]
homicide_data <- read_tsv(here("data", "Homicide deaths 2018-2020.txt")) %>%
  clean_csv() %>%
  select(county_code, population, deaths) %>%
  mutate(homicide_rate = deaths / (population / 100000)) %>%
  select(county_code, homicide_rate)

providers_filtering_states <- left_join(providers_filtering_states, homicide_data)
providers_filtering_states_scaled <- left_join(providers_filtering_states_scaled, homicide_data)
providers_psychiatrists_alone <- left_join(providers_psychiatrists_alone, homicide_data)
providers_psychiatrists_alone_scaled <- left_join(providers_psychiatrists_alone_scaled, homicide_data)

rm(suicide_data, homicide_data, clean_csv)