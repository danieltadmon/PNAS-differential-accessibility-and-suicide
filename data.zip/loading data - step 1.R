source(here("3 accessibility score calculator.R"))
psychiatrist_access <- access_score_function(read_csv(here("data", "psychiatrists_3sfca.csv")), "combined_3sfca")
therapist_access <- access_score_function(read_csv(here("data", "therapists_3sfca.csv")), "combined_3sfca")

colnames(psychiatrist_access) <- ifelse(colnames(psychiatrist_access) != "GEOID", paste0("psychiatrist_", colnames(psychiatrist_access)), colnames(psychiatrist_access))
colnames(therapist_access) <- ifelse(colnames(therapist_access) != "GEOID", paste0("therapist_", colnames(therapist_access)), colnames(therapist_access))

state_fips_to_exclude <- c("01", "15", "20", "21", "24", "27", "28", "32", "33", "35", "46", "53", "56")

therapist_access <- therapist_access %>% 
  mutate(first_digits = str_extract(GEOID, "^..")) %>% 
  filter(!first_digits %in% state_fips_to_exclude) %>% 
  select(-first_digits)
  
providers <- left_join(psychiatrist_access, therapist_access)
rm(psychiatrist_access, therapist_access)

# using table B03002 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "B03002.csv"))[-1, ] %>% 
  rename(total_pop = "B03002_001E",
         total_pop_white_non_hispanic = "B03002_003E",
         total_pop_black_non_hispanic = "B03002_004E",
         total_pop_asian_non_hispanic = "B03002_006E",
         total_pop_hispanic_all_races = "B03002_012E") %>%
  select(GEOID = GEO_ID, 
         starts_with("total_pop")) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US")) %>% 
  mutate(across(matches("total_pop"), as.numeric)) %>% 
  mutate(total_pop_race_other = total_pop - total_pop_white_non_hispanic - total_pop_black_non_hispanic - total_pop_asian_non_hispanic - total_pop_hispanic_all_races) 

providers <- left_join(providers, x)
rm(x)

# using table C02003 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "C02003.csv"))[-1, ] %>% 
  rename(GEOID = GEO_ID,
         total_pop = C02003_001E,
         total_pop_white_alone = C02003_003E,
         total_pop_black_alone = C02003_004E,
         total_pop_asian_alone = C02003_006E) %>% 
  select(GEOID, matches("total_pop")) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US")) %>%
  mutate(across(-GEOID, as.numeric))

providers <- left_join(providers, x)
rm(x)

# using table DP02 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "DP02.csv"))[-1, ] %>% 
  select(GEOID = GEO_ID,
         males_over_15 = DP02_0025E,
         males_over_15_separated = DP02_0028E,
         males_over_15_divorced = DP02_0030E,
         females_over_15 = DP02_0031E,
         females_over_15_separated = DP02_0034E,
         females_over_15_divorced = DP02_0036E,
         pct_born_in_the_usa = DP02_0089PE,
         education_pop_over_25 = DP02_0059E,
         ba_degree_or_higher_pop_over_25 = DP02_0068E) %>% 
  mutate(across(matches("_"), ~as.numeric(.))) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US"),
         prop_separated_or_divorced = (males_over_15_separated + males_over_15_divorced + 
                                         females_over_15_separated + 
                                         females_over_15_divorced) / (males_over_15 + females_over_15)) %>% 
  mutate(separated_or_divorced_in_10_pct = prop_separated_or_divorced * 10,
         pct_born_in_the_usa_in_10_pct = pct_born_in_the_usa / 10) %>% 
  mutate(education_pop_over_25 = as.numeric(education_pop_over_25),
         ba_degree_or_higher_pop_over_25 = as.numeric(ba_degree_or_higher_pop_over_25),
         ba_degree_over_25_prop_in_pct = (ba_degree_or_higher_pop_over_25 / education_pop_over_25)*10) %>%
  select(GEOID, pct_born_in_the_usa_in_10_pct, separated_or_divorced_in_10_pct, ba_degree_over_25_prop_in_pct)

providers <- left_join(providers, x)
rm(x)

# using table B19013 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "B19013.csv"))[-1, ] %>% 
  select(GEOID = GEO_ID,
         med_household_income = "B19013_001E") %>% 
  mutate(GEOID = str_remove(GEOID, ".*US"),
         med_household_income = as.numeric(med_household_income))

providers <- left_join(providers, x)
rm(x)

providers <- providers %>% 
  mutate(med_household_income_in_10K = med_household_income / 10000,
         pop_white_non_hispanic_in_pct = (total_pop_white_non_hispanic / total_pop) * 100,
         pop_black_non_hispanic_in_pct = (total_pop_black_non_hispanic / total_pop) * 100,
         pop_hispanic_all_races_in_pct = (total_pop_hispanic_all_races / total_pop) * 100,
         pop_asian_non_hispanic_in_pct = (total_pop_asian_non_hispanic / total_pop) * 100,
         pop_white_alone_in_pct = (total_pop_white_alone / total_pop) * 100,
         pop_black_alone_in_pct = (total_pop_black_alone / total_pop) * 100,
         pop_asian_alone_in_pct = (total_pop_asian_alone / total_pop) * 100,
         pop_race_other_in_pct = (total_pop_race_other / total_pop) * 100) %>% 
  mutate(county_fips = str_extract(GEOID, "^....."),
         state_fips = str_extract(GEOID, "^.."))

# using 2010 ruca [https://www.ers.usda.gov/data-products/rural-urban-commuting-area-codes/]
ruca <- read_csv(here("data", "ruca2010revised.csv")) %>% 
  janitor::clean_names() %>% 
  rename(GEOID = "state_county_tract_fips_code_lookup_by_address_at_http_www_ffiec_gov_geocode")

county_fips <- read_csv(here("data", "county_state_fips.csv"))
state_fips <- read_csv(here("data", "state_fips.csv"))
land_area <- read_csv(here("data", "census_2010_tract_land_area.csv")) %>% 
  mutate(land_area_sq_mile = land_area_sq_meters * 3.861e-7) %>% 
  select(-land_area_sq_meters)
  
providers <- providers %>% 
  # left_join(acs) %>% 
  left_join(ruca %>% 
              select(GEOID, rurality_1_to_10 = primary_ruca_code_2010) %>% 
              mutate(rurality_1_to_10 = ifelse(rurality_1_to_10 %in% 99, NA, rurality_1_to_10)) %>% 
              mutate(rural_urban = case_when(rurality_1_to_10 <= 3 ~ "Metropolitan",
                                                 rurality_1_to_10 %in% c(4,5,6) ~ "Micropolitan",
                                                 rurality_1_to_10 >= 7 ~ "Small town and rural",
                                                 TRUE ~ "IRRELEVANT")) %>% 
              mutate(rural_urban = ifelse(rural_urban == "IRRELEVANT", NA, rural_urban))) %>% 
  left_join(state_fips, by = c("state_fips" = "fips")) %>% 
  left_join(county_fips %>% 
              select(-state_abbreviation), 
            by = c("county_fips" = "fips")) %>% 
  left_join(land_area) %>% 
  mutate(pop_density_1k_ppl_per_sq_mile = (total_pop / land_area_sq_mile) / 1000) %>% 
  select(-county_name, -county_fips, -state_fips, -land_area_sq_mile)

# using table S2301 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "S2301.csv"))[-1, ] %>%  
  rename(unemployment_rate_in_pct = S2301_C04_001E) %>% 
  select(GEOID = GEO_ID, 
         unemployment_rate_in_pct) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US"))

providers <- left_join(providers, x)
rm(x)

# using table DP03 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv("~/Downloads/ACSDP5Y2019.DP03_2023-03-14T154301/DP03.csv")[-1, ] %>% 
  select(county_code = GEO_ID, DP03_0003E, DP03_0005E) %>% 
  mutate(county_code = str_remove(county_code, ".*US"),
         across(matches("DP03"), as.numeric)) %>% 
  mutate(unemployment_rate_in_pct = (DP03_0005E / DP03_0003E) * 100)

providers <- left_join(providers %>% 
                         select(-unemployment_rate_in_pct) %>% 
                         mutate(county_code = str_extract(GEOID, "^.....")), x) %>% 
  select(-county_code)
  
rm(x)

# using table B27010 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "B27010.csv"))[-1, ] %>% 
  mutate(across(starts_with("B27010"), as.numeric)) %>% 
  mutate(insurance_rate_under_19 = 1 - (B27010_017E / B27010_002E), 
         insurance_rate_19_to_34 = 1 - (B27010_033E / B27010_018E),  
         insurance_rate_35_to_64 = 1 - (B27010_050E / B27010_034E),  
         insurance_rate_over_65 = 1 - (B27010_066E / B27010_051E)) %>% 
  mutate(insurance_rate = ((insurance_rate_under_19 * B27010_002E) + (insurance_rate_19_to_34 * B27010_018E) + 
                             (insurance_rate_35_to_64 * B27010_034E) + (insurance_rate_over_65 * B27010_051E)) / B27010_001E) %>% 
  mutate(insurance_rate_in_pct = insurance_rate * 100) %>% 
  select(GEO_ID, insurance_rate_in_pct) %>%
  rename(GEOID = GEO_ID) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US"))

is.nan.data.frame <- function(x) do.call(cbind, lapply(x, is.nan))
x[is.nan.data.frame(x)] <- NA

providers <- providers %>% 
  left_join(x)

rm(x, is.nan.data.frame)

# using table S1701 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "S1701.csv"))[-1, ] %>% 
  mutate(poverty_in_pct = (as.numeric(S1701_C02_001E) / as.numeric(S1701_C01_001E)) * 100) %>% 
  select(GEO_ID, poverty_in_pct) %>%
  rename(GEOID = GEO_ID) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US"))

providers <- left_join(providers, x)
rm(x)

# using 2019 ADI block group data [https://www.neighborhoodatlas.medicine.wisc.edu/]
adi <- read_csv(here("data", "adi.csv"))[, -1]
census_block_pop <- read_csv(here("data", "block group.csv"))
adi <- left_join(adi, census_block_pop)

adi$ADI_NATRANK <- ifelse(str_detect(adi$ADI_NATRANK, "G|P|Q|N"), NA, adi$ADI_NATRANK)
adi$ADI_NATRANK <- as.numeric(adi$ADI_NATRANK)
adi$ADI_STATERNK <- ifelse(str_detect(adi$ADI_STATERNK, "G|P|Q|N"), NA, adi$ADI_STATERNK)
adi$ADI_STATERNK <- as.numeric(adi$ADI_STATERNK)

adi <- adi %>% 
  mutate(FIPS = str_remove(FIPS, ".$")) %>% 
  group_by(FIPS) %>% 
  summarize(ADI_NATRANK = Hmisc::wtd.mean(ADI_NATRANK, na.rm = TRUE, weights = pop),
            ADI_STATERNK = Hmisc::wtd.mean(ADI_STATERNK, na.rm = TRUE, weights = pop)) %>% 
  ungroup

providers <- left_join(providers, adi, by = c("GEOID" = "FIPS"))
rm(adi, census_block_pop)

# using table B19083 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "B19083.csv"))[-1, ] %>% 
  select(county_code = GEO_ID,
         acs_county_level_gini = B19083_001E) %>% 
  mutate(county_code = str_remove(county_code, ".*US"))

providers <- inner_join(providers %>% 
                          mutate(county_code = str_extract(GEOID, "^.....")), x)  
rm(x)

# using table S0101 from 2015-2019 ACS [https://data.census.gov/table]
x <- read_csv(here("data", "S0101.csv"))[-1, ] %>% 
  select(GEOID = GEO_ID,
         median_age = S0101_C01_032E,
         males_per_100_females = S0101_C01_033E) %>% 
  mutate(GEOID = str_remove(GEOID, ".*US"),
         median_age = as.numeric(median_age),
         males_per_100_females = as.numeric(males_per_100_females)) %>% 
  mutate(pop_prop_male = (males_per_100_females / (males_per_100_females + 100))) %>% 
  mutate(males_in_10_pct = pop_prop_male * 10) %>% 
  select(-males_per_100_females, -pop_prop_male)

providers <- left_join(providers, x)
rm(x)

# county-level psychiatrist and therapist counts 
psychiatrists <- read_csv(here("data", "psychiatrists.csv")) %>% 
  uncount(value) %>% 
  filter(!is.na(lat))

therapists <- read_csv(here("data", "therapists.csv")) %>% 
  uncount(value) %>% 
  filter(!is.na(lat))

# load county shapefile [https://www.census.gov/geographies/mapping-files/2018/geo/carto-boundary-file.html]
county_shp <- sf::read_sf(here("data", "cb_2018_us_county_5m", "cb_2018_us_county_5m.shp"))
psychiatrist_points <- sf::st_as_sf(psychiatrists, coords = c('lon', 'lat'), crs = sf::st_crs(county_shp))
therapist_points <- sf::st_as_sf(therapists, coords = c('lon', 'lat'), crs = sf::st_crs(county_shp))
county_shp$county_psychiatrist_count <- lengths(sf::st_intersects(county_shp, psychiatrist_points))
county_shp$county_therapist_count <- lengths(sf::st_intersects(county_shp, therapist_points))
state_fips_to_exclude <- as.numeric(c("01", "15", "20", "21", "24", "27", "28", "32", "33", "35", "46", "53", "56"))

providers_per_county <- county_shp %>% 
  sf::st_drop_geometry() %>% 
  select(GEOID, county_psychiatrist_count, county_therapist_count) %>% 
  mutate(state_fips = as.numeric(str_extract(GEOID, "^.."))) %>% 
  filter(state_fips <= 56) %>% 
  mutate(county_therapist_count = ifelse(state_fips %in% state_fips_to_exclude, NA, county_therapist_count)) %>% 
  select(-state_fips)

providers <- left_join(providers, providers_per_county, by = c("county_code" = "GEOID")) 

rm(county_shp, state_fips_to_exclude, providers_per_county, psychiatrists, psychiatrist_points, therapists, therapist_points)

# excluding 13 states
providers_psychiatrists_alone <- providers 
excluded_states <- c("ALABAMA", "HAWAII", "KANSAS", "KENTUCKY", "MARYLAND", "MINNESOTA", "MISSISSIPPI", "NEVADA", "NEW HAMPSHIRE", "NEW MEXICO", "SOUTH DAKOTA", "WASHINGTON", "WYOMING")
providers_filtering_states <- providers %>% 
  filter(!state %in% excluded_states)

rm(providers, excluded_states, county_fips, land_area, ruca, state_fips, access_score_function)