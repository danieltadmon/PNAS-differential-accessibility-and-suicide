# using geography of social capital data [https://www.jec.senate.gov/public/index.cfm/republicans/2018/4/the-geography-of-social-capital-in-america]
x <- read_csv(here("data", "social_capital.csv")) %>% 
  janitor::clean_names() %>%
  select(county_code = fips_code, county_level_index, matches("^final")) %>% 
  mutate(county_code = str_pad(county_code, 5, side = "left", pad = "0")) %>% 
  rename(soc_capital_index = county_level_index,
         soc_capital_family_unity = final_index_family_unity,
         soc_capital_community_health = final_index_community_health,
         soc_capital_institutional_health = final_index_institutional_health,
         soc_capital_collective_efficacy = final_index_collective_efficacy)

access_df <- left_join(access_df, x)
rm(x)

# using firearms and liquor business data [https://www.data-axle.com/our-data/business-data/] 
all_businesses <- read_csv(here("data", "businesses_all.csv"))
guns <- read_csv(here("data", "businesses_firearms.csv"))
liquor <- read_csv(here("data", "businesses_liquor.csv"))

guns <- guns %>% 
  count(archive_version_year, fips_code) %>% 
  group_by(fips_code) %>% 
  summarize(number_gun_stores = mean(n, na.rm = TRUE))

liquor <- liquor %>% 
  count(archive_version_year, fips_code) %>% 
  group_by(fips_code) %>% 
  summarize(number_liquor_stores_and_drinking_establishments = mean(n, na.rm = TRUE))

businesses <- left_join(all_businesses, liquor) %>% 
  left_join(guns) %>% 
  mutate(gun_store_ratio = number_gun_stores / number,
         liquor_and_drinking_ratio = number_liquor_stores_and_drinking_establishments / number) %>%
  mutate(gun_store_ratio = ifelse(is.na(gun_store_ratio), 0, gun_store_ratio),
         liquor_and_drinking_ratio = ifelse(is.na(liquor_and_drinking_ratio), 0, liquor_and_drinking_ratio)) %>% 
  select(county_code = fips_code,
         gun_store_ratio, liquor_and_drinking_ratio)

businesses$gun_store_ratio <- scale(businesses$gun_store_ratio)
businesses$liquor_and_drinking_ratio <- scale(businesses$liquor_and_drinking_ratio)
businesses$gun_store_ratio <- pull(businesses, gun_store_ratio) %>% as.vector()
businesses$liquor_and_drinking_ratio <- pull(businesses, liquor_and_drinking_ratio) %>% as.vector()

access_df <- left_join(access_df, businesses)
rm(all_businesses, businesses, guns, liquor, providers_filtering_states, providers_filtering_states_scaled, providers_psychiatrists_alone)