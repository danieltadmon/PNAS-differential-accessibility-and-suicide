outlier_psychiatrist_tracts <- providers_psychiatrists_alone %>% 
  mutate(scaled = scale(psychiatrist_general_tract_access)) %>% 
  filter(scaled >= 4) %>% 
  select(GEOID, total_pop)

outlier_therapist_tracts <- providers_filtering_states %>% 
  mutate(scaled = scale(therapist_general_tract_access)) %>% 
  filter(scaled >= 4) %>% 
  select(GEOID, total_pop)

outliers <- c(outlier_psychiatrist_tracts %>% pull(GEOID), outlier_therapist_tracts %>% pull(GEOID)) %>% unique

providers_psychiatrists_alone <- providers_psychiatrists_alone %>% 
  filter(!GEOID %in% outliers) 

providers_filtering_states <- providers_filtering_states %>% 
  filter(!GEOID %in% outliers) 
 
rm(outliers, outlier_psychiatrist_tracts, outlier_therapist_tracts)