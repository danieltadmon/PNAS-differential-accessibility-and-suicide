access_score_function <- function(df, variable){
  
  df <- df %>% 
    rename(access = {{variable}}) %>% 
    select(geoid, access) %>% 
    filter(access >= 0) %>% 
    rename(GEOID = geoid) %>% 
    mutate(modality = str_extract(GEOID, "(?<=\\_)\\D+")) %>% 
    mutate(GEOID = str_remove(GEOID, "\\_.*")) %>% 
    mutate(GEOID = str_pad(GEOID, width = 11, side = "left", pad = "0")) 
  
  population <- read_csv(here("data", "population.csv")) %>% 
    rename(GEOID = origin)
  
  population <- population %>% 
    mutate(modality = str_extract(GEOID, "(?<=\\_)\\D+")) %>% 
    mutate(GEOID = str_remove(GEOID, "\\_.*")) %>% 
    mutate(GEOID = str_pad(GEOID, width = 11, side = "left", pad = "0")) 
  
  output <- inner_join(population, df, by = c("GEOID", "modality")) %>% 
    group_by(GEOID) %>% 
    summarize(general_tract_access = Hmisc::wtd.mean(access, weights = total_pop, na.rm = TRUE))

  return(output)
}
