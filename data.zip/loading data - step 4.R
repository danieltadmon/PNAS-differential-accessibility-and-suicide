# Since accessibility is calculated at level-1 (Census tract) but the dependent variable, suicide rate, is at level-2 (county), we need to assess level-2, county mean accessibility by aggregating census tracts

access_df <- providers_psychiatrists_alone_scaled %>%
  group_by(county_code) %>% 
  summarize(psychiatrist_general_tract_access = 
              Hmisc::wtd.mean(psychiatrist_general_tract_access, weights = total_pop, na.rm = TRUE),
            psychiatrist_general_tract_access_unscaled = 
              Hmisc::wtd.mean(psychiatrist_general_tract_access_unscaled, weights = total_pop, na.rm = TRUE),
            pop_density_1k_ppl_per_sq_mile = 
              Hmisc::wtd.mean(pop_density_1k_ppl_per_sq_mile, weights = total_pop, na.rm = TRUE),
            poverty_in_10_pct=
              Hmisc::wtd.mean(poverty_in_10_pct, weights = total_pop, na.rm = TRUE),
            separated_or_divorced_in_10_pct=
              Hmisc::wtd.mean(separated_or_divorced_in_10_pct, weights = total_pop, na.rm = TRUE),
            pct_born_in_the_usa_in_10_pct=
              Hmisc::wtd.mean(pct_born_in_the_usa_in_10_pct, weights = total_pop, na.rm = TRUE),
            insurance_rate_in_10_pct=
              Hmisc::wtd.mean(insurance_rate_in_10_pct, weights = total_pop, na.rm = TRUE),
            unemployment_rate_in_10_pct=
              Hmisc::wtd.mean(unemployment_rate_in_10_pct, weights = total_pop, na.rm = TRUE),
            median_age=
              Hmisc::wtd.mean(median_age, weights = total_pop, na.rm = TRUE),
            males_in_10_pct=
              Hmisc::wtd.mean(males_in_10_pct, weights = total_pop, na.rm = TRUE),
            ADI_NATRANK = 
              Hmisc::wtd.mean(ADI_NATRANK, weights = total_pop, na.rm = TRUE),
            rurality_1_to_10 = 
              Hmisc::wtd.mean(rurality_1_to_10, weights = total_pop, na.rm = TRUE),
            med_household_income_in_10K = 
              Hmisc::wtd.mean(med_household_income_in_10K, weights = total_pop, na.rm = TRUE),
            ba_degree_over_25_prop_in_10_pct = 
              Hmisc::wtd.mean(ba_degree_over_25_prop_in_10_pct, weights = total_pop, na.rm = TRUE),
            pop_white_non_hispanic_in_10_pct = 
              Hmisc::wtd.mean(pop_white_non_hispanic_in_10_pct, weights = total_pop, na.rm = TRUE),
            pop_black_non_hispanic_in_10_pct = 
              Hmisc::wtd.mean(pop_black_non_hispanic_in_10_pct, weights = total_pop, na.rm = TRUE),
            pop_asian_non_hispanic_in_10_pct = 
              Hmisc::wtd.mean(pop_asian_non_hispanic_in_10_pct, weights = total_pop, na.rm = TRUE),
            pop_hispanic_all_races_in_10_pct = 
              Hmisc::wtd.mean(pop_hispanic_all_races_in_10_pct, weights = total_pop, na.rm = TRUE)) %>% 
  left_join(providers_psychiatrists_alone_scaled %>% 
              group_by(county_code) %>% 
              mutate(total_pop = sum(total_pop, na.rm = TRUE)) %>% 
              select(county_code, suicide_rate, homicide_rate, total_pop, state, acs_county_level_gini,
                     county_gini_psychiatrist, county_psychiatrist_count)) %>% 
  left_join(providers_filtering_states %>% 
              distinct(county_code, county_gini_therapist, county_therapist_count)) %>% 
  left_join(providers_filtering_states_scaled %>% 
              group_by(county_code) %>% 
              summarize(therapist_general_tract_access = Hmisc::wtd.mean(therapist_general_tract_access, weights = total_pop, na.rm = TRUE),
                        therapist_general_tract_access_unscaled = Hmisc::wtd.mean(therapist_general_tract_access_unscaled, weights = total_pop, na.rm = TRUE)) %>% 
              ungroup
  ) %>% 
  distinct 